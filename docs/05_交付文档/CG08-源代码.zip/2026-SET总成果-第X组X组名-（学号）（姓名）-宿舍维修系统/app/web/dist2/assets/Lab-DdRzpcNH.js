import { o as onMounted, c as createElementBlock, a as createBaseVNode, t as toDisplayString, k as withModifiers, u as unref, b as createTextVNode, d as createCommentVNode, w as withDirectives, p as vModelSelect, F as Fragment, r as renderList, n as normalizeClass, f as ref, e as useRouter, j as computed, g as openBlock } from "./index-CQHsh9DN.js";
import { _ as _export_sfc, o as ordersApi, d as describeError } from "./_plugin-vue_export-helper-CJxN7Dmm.js";
import { E as EVENT, S as STATUS } from "./status-BDo8bc0j.js";
const _hoisted_1 = { class: "desk" };
const _hoisted_2 = { class: "desk-side" };
const _hoisted_3 = { class: "brand" };
const _hoisted_4 = { class: "desk-main" };
const _hoisted_5 = { class: "desk-top" };
const _hoisted_6 = { class: "hint" };
const _hoisted_7 = { class: "desk-wrap" };
const _hoisted_8 = {
  key: 0,
  class: "note",
  "data-tone": "bad"
};
const _hoisted_9 = {
  key: 1,
  class: "note"
};
const _hoisted_10 = { class: "lab-grid" };
const _hoisted_11 = { class: "col" };
const _hoisted_12 = { class: "panel" };
const _hoisted_13 = { class: "hint" };
const _hoisted_14 = { class: "pn" };
const _hoisted_15 = ["value"];
const _hoisted_16 = {
  key: 0,
  class: "cur"
};
const _hoisted_17 = ["data-st"];
const _hoisted_18 = { class: "v" };
const _hoisted_19 = { class: "v" };
const _hoisted_20 = {
  key: 0,
  class: "v"
};
const _hoisted_21 = {
  key: 1,
  class: "v warn"
};
const _hoisted_22 = { class: "panel" };
const _hoisted_23 = { class: "pn" };
const _hoisted_24 = ["disabled", "onClick"];
const _hoisted_25 = { class: "l1" };
const _hoisted_26 = { class: "l2" };
const _hoisted_27 = {
  key: 0,
  class: "empty"
};
const _hoisted_28 = { class: "panel" };
const _hoisted_29 = { class: "pn" };
const _hoisted_30 = ["disabled", "onClick"];
const _hoisted_31 = { class: "l1" };
const _hoisted_32 = { class: "l2" };
const _hoisted_33 = { class: "hint" };
const _hoisted_34 = { class: "pn" };
const _hoisted_35 = { class: "col" };
const _hoisted_36 = { class: "panel" };
const _hoisted_37 = { class: "hint" };
const _hoisted_38 = { class: "pn pn0" };
const _hoisted_39 = { class: "mxwrap" };
const _hoisted_40 = { class: "mx" };
const _hoisted_41 = { class: "sticky" };
const _hoisted_42 = { class: "panel-foot" };
const _hoisted_43 = { class: "panel" };
const _hoisted_44 = { class: "pn pn0" };
const _hoisted_45 = { class: "dt tr" };
const _hoisted_46 = { class: "n" };
const _hoisted_47 = { class: "ev" };
const _hoisted_48 = { class: "who" };
const _sfc_main = {
  __name: "Lab",
  setup(__props) {
    const router = useRouter();
    const meta = ref({ statuses: [], events: [], transitions: [], buildings: [] });
    const matrix = ref({ rows: [], rowCount: 0, eventCount: 0, total: 0, legal: 0 });
    const orders = ref([]);
    const picked = ref("");
    const result = ref(null);
    const busy = ref("");
    const booting = ref(true);
    const bootErr = ref("");
    const order = computed(() => orders.value.find((o) => o.no === picked.value) || null);
    const trs = ref([]);
    const transitions = computed(() => trs.value);
    function triggerOf(ev) {
      const t = transitions.value.find((x) => x.event === ev);
      return t ? t.trigger || [] : [];
    }
    function rowOf(st) {
      const row = (matrix.value.rows || []).find((r) => r.from === st);
      return row ? row.cells || [] : [];
    }
    const allowed = computed(() => {
      if (!order.value) return [];
      const list = rowOf(order.value.status).filter((c) => c.legal).map((c) => ({ ev: c.event, to: c.to, trigger: triggerOf(c.event) }));
      if (order.value.status === "REPAIRING" && !list.some((x) => x.ev === "CANCEL_REQUEST")) {
        list.push({ ev: "CANCEL_REQUEST", to: null, trigger: ["student"] });
      }
      return list;
    });
    const rejected = computed(() => {
      if (!order.value) return [];
      return rowOf(order.value.status).filter((c) => !c.legal).map((c) => ({ ev: c.event, trigger: triggerOf(c.event) }));
    });
    const EP = {
      ASSIGN: "assign",
      ARRIVE: "arrive",
      NO_SHOW: "no-show",
      FINISH: "finish",
      NEED_PARTS: "need-parts",
      PARTS_ARRIVED: "parts-arrived",
      ACCEPT: "accept",
      REJECT: "reject",
      CANCEL: "cancel",
      CANCEL_REQUEST: "cancel-request",
      AUTO_ACCEPT: "auto-accept",
      ARCHIVE: "archive"
    };
    function tomorrow() {
      const d = new Date(Date.now() + 864e5);
      return d.toISOString().slice(0, 10);
    }
    function payloadFor(ev) {
      var _a;
      switch (ev) {
        case "NO_SHOW":
          return { reason: "KNOCK_NO_ANSWER", note: "自检台演示" };
        case "FINISH":
          return { photosAfter: ["demo://lab/after.jpg"], noteTags: ["更换软管"], note: "自检台演示" };
        case "NEED_PARTS":
          return { partsName: "演示配件", partsAmount: 50, partsEta: tomorrow() };
        case "ACCEPT":
          return { signerName: ((_a = order.value) == null ? void 0 : _a.studentName) || "演示签字" };
        case "REJECT":
          return { reason: "还没修好（自检台演示）" };
        case "CANCEL":
          return { reason: "不需要修了" };
        case "CANCEL_REQUEST":
          return { reason: "等太久了（自检台演示）" };
        case "ASSIGN":
          return {};
        default:
          return {};
      }
    }
    function optsFor(ev) {
      var _a, _b;
      const trig = triggerOf(ev);
      if (trig.includes("worker")) return { role: "worker", id: ((_a = order.value) == null ? void 0 : _a.workerId) || null };
      if (trig.includes("student")) return { role: "student", id: ((_b = order.value) == null ? void 0 : _b.studentId) || null };
      if (trig.includes("admin")) return { role: "admin", id: "A001" };
      return { role: "system", id: "system" };
    }
    function labelOf(ev) {
      return EVENT[ev] || ev;
    }
    function stLabel(st) {
      return STATUS[st] || st;
    }
    async function push(ev) {
      const ep = EP[ev];
      if (!order.value || !ep) return;
      const opts = optsFor(ev);
      if (opts.role === "worker" && !opts.id) {
        result.value = { ok: false, code: 403, title: "这单还没派师傅", lines: ["点下去只会得到 403：这条边的触发方是师傅，而单子上没有师傅。"] };
        return;
      }
      busy.value = ev;
      const before = { status: order.value.status, version: order.value.version };
      try {
        const body = { ...payloadFor(ev), version: order.value.version };
        const r = await ordersApi[ep === "assign" ? "assign" : ep === "arrive" ? "arrive" : ep === "no-show" ? "noShow" : ep === "finish" ? "finish" : ep === "need-parts" ? "needParts" : ep === "parts-arrived" ? "partsArrived" : ep === "accept" ? "accept" : ep === "reject" ? "reject" : ep === "cancel" ? "cancel" : ep === "cancel-request" ? "cancelRequest" : "adminCancel"](order.value.no, body, opts);
        result.value = {
          ok: true,
          code: 200,
          title: `${labelOf(ev)} 成功：${stLabel(before.status)} → ${stLabel(r.status)}`,
          lines: [`版本 v${before.version} → v${r.version}`, `状态时间 ${r.statusAt}`, `以「${opts.role}${opts.id ? " " + opts.id : ""}」身份提交`]
        };
      } catch (e) {
        const d = e.detail || {};
        const lines = [];
        if (e.status === 409) {
          lines.push(d.message || "状态机不接受这条边");
          if (d.reason === "VERSION_CONFLICT") {
            lines.push(`版本对不上：服务端是 v${d.serverVersion ?? d.gotVersion ?? "?"}，你手上是 v${d.clientVersion ?? d.expectVersion ?? "?"}`);
          } else if (d.allowed) {
            lines.push("这单现在只能做：" + (d.allowed || []).map(labelOf).join(" / "));
          }
          const now = await ordersApi.detail(order.value.no).catch(() => null);
          if (now) lines.push(`工单一个字没动：仍是 ${stLabel(now.status)}，version 仍是 ${now.version}`);
        } else if (e.status === 403) {
          lines.push(d.message || "这个身份不能调这个接口");
        } else if (e.status === 422) {
          lines.push(d.message || "前置条件不满足");
        } else {
          lines.push(describeError(e));
        }
        result.value = { ok: false, code: e.status, title: `${labelOf(ev)} 被拒（HTTP ${e.status}）`, lines };
      } finally {
        busy.value = "";
        await loadOrders();
      }
    }
    async function loadOrders() {
      var _a;
      try {
        const r = await ordersApi.list({ pageSize: 100 });
        orders.value = r.items || [];
        if (!orders.value.find((o) => o.no === picked.value)) picked.value = ((_a = orders.value[0]) == null ? void 0 : _a.no) || "";
      } catch (e) {
        bootErr.value = describeError(e);
      }
    }
    onMounted(async () => {
      try {
        const [m, mx, tr] = await Promise.all([ordersApi.meta(), ordersApi.matrix(), ordersApi.transitions(), loadOrders()]);
        meta.value = m;
        matrix.value = mx;
        trs.value = tr.items || [];
      } catch (e) {
        bootErr.value = describeError(e);
      } finally {
        booting.value = false;
      }
    });
    return (_ctx, _cache) => {
      var _a;
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("aside", _hoisted_2, [
          createBaseVNode("div", _hoisted_3, [
            _cache[5] || (_cache[5] = createBaseVNode("span", { class: "mk" }, "修", -1)),
            createBaseVNode("div", null, [
              _cache[4] || (_cache[4] = createBaseVNode("b", null, "状态机自检台", -1)),
              createBaseVNode("i", null, toDisplayString(matrix.value.total || 130) + " 种组合，合法 " + toDisplayString(matrix.value.legal || 13) + " 条", 1)
            ])
          ]),
          createBaseVNode("nav", null, [
            createBaseVNode("a", {
              href: "#",
              class: "on",
              onClick: _cache[0] || (_cache[0] = withModifiers(() => {
              }, ["prevent"]))
            }, "自检台"),
            createBaseVNode("button", {
              onClick: _cache[1] || (_cache[1] = ($event) => unref(router).push("/admin"))
            }, "管理端"),
            createBaseVNode("button", {
              onClick: _cache[2] || (_cache[2] = ($event) => unref(router).push("/"))
            }, "回到入口")
          ]),
          _cache[6] || (_cache[6] = createBaseVNode("div", { class: "side-foot" }, [
            createTextVNode(" 这里不做业务判断，只把状态机摆出来让人点。"),
            createBaseVNode("br"),
            createTextVNode("出边是表里查的，不是页面自己写的。 ")
          ], -1))
        ]),
        createBaseVNode("main", _hoisted_4, [
          createBaseVNode("header", _hoisted_5, [
            _cache[7] || (_cache[7] = createBaseVNode("h1", null, "状态机自检台", -1)),
            createBaseVNode("div", _hoisted_6, "9 个状态 + 1 个新建入口，13 个事件，共 " + toDisplayString(matrix.value.total || 130) + " 种组合 —— 只有 " + toDisplayString(matrix.value.legal || 13) + " 条能走通", 1),
            _cache[8] || (_cache[8] = createBaseVNode("div", { class: "sp" }, null, -1)),
            createBaseVNode("button", {
              class: "dbtn",
              onClick: loadOrders
            }, "刷新")
          ]),
          createBaseVNode("div", _hoisted_7, [
            bootErr.value ? (openBlock(), createElementBlock("p", _hoisted_8, toDisplayString(bootErr.value), 1)) : booting.value ? (openBlock(), createElementBlock("p", _hoisted_9, "加载中…")) : createCommentVNode("", true),
            createBaseVNode("div", _hoisted_10, [
              createBaseVNode("div", _hoisted_11, [
                createBaseVNode("section", _hoisted_12, [
                  createBaseVNode("header", null, [
                    _cache[9] || (_cache[9] = createBaseVNode("b", null, "选一张单手动推", -1)),
                    _cache[10] || (_cache[10] = createBaseVNode("span", { class: "spacer" }, null, -1)),
                    createBaseVNode("span", _hoisted_13, toDisplayString(orders.value.length) + " 张", 1)
                  ]),
                  createBaseVNode("div", _hoisted_14, [
                    withDirectives(createBaseVNode("select", {
                      "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => picked.value = $event),
                      class: "sel"
                    }, [
                      (openBlock(true), createElementBlock(Fragment, null, renderList(orders.value, (o) => {
                        return openBlock(), createElementBlock("option", {
                          key: o.no,
                          value: o.no
                        }, toDisplayString(o.no) + " · " + toDisplayString(o.statusLabel) + " · " + toDisplayString(o.building) + " " + toDisplayString(o.room), 9, _hoisted_15);
                      }), 128))
                    ], 512), [
                      [vModelSelect, picked.value]
                    ]),
                    order.value ? (openBlock(), createElementBlock("div", _hoisted_16, [
                      createBaseVNode("span", {
                        class: "pill",
                        "data-st": order.value.status
                      }, toDisplayString(order.value.statusLabel), 9, _hoisted_17),
                      createBaseVNode("span", _hoisted_18, "version " + toDisplayString(order.value.version), 1),
                      createBaseVNode("span", _hoisted_19, toDisplayString(order.value.building) + " " + toDisplayString(order.value.floor) + "F-" + toDisplayString(order.value.room), 1),
                      order.value.workerName ? (openBlock(), createElementBlock("span", _hoisted_20, "师傅 " + toDisplayString(order.value.workerName), 1)) : (openBlock(), createElementBlock("span", _hoisted_21, "没派师傅"))
                    ])) : createCommentVNode("", true)
                  ])
                ]),
                createBaseVNode("section", _hoisted_22, [
                  _cache[11] || (_cache[11] = createBaseVNode("header", null, [
                    createBaseVNode("b", null, "允许的事件"),
                    createBaseVNode("span", { class: "spacer" }),
                    createBaseVNode("span", { class: "hint" }, "点下去应该成功")
                  ], -1)),
                  createBaseVNode("div", _hoisted_23, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(allowed.value, (a) => {
                      return openBlock(), createElementBlock("button", {
                        key: a.ev,
                        class: "evbtn",
                        disabled: busy.value === a.ev,
                        onClick: ($event) => push(a.ev)
                      }, [
                        createBaseVNode("span", _hoisted_25, [
                          createTextVNode(toDisplayString(labelOf(a.ev)), 1),
                          a.to ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                            createTextVNode(" → " + toDisplayString(stLabel(a.to)), 1)
                          ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                            createTextVNode(" · 只留记录")
                          ], 64))
                        ]),
                        createBaseVNode("span", _hoisted_26, toDisplayString(a.ev) + " · " + toDisplayString((a.trigger || []).join("/")), 1)
                      ], 8, _hoisted_24);
                    }), 128)),
                    !allowed.value.length ? (openBlock(), createElementBlock("p", _hoisted_27, "这单现在没有能走的路（终态）。")) : createCommentVNode("", true)
                  ])
                ]),
                createBaseVNode("section", _hoisted_28, [
                  _cache[12] || (_cache[12] = createBaseVNode("header", null, [
                    createBaseVNode("b", null, "会被拒的事件"),
                    createBaseVNode("span", { class: "spacer" }),
                    createBaseVNode("span", { class: "hint" }, "点下去应该 409")
                  ], -1)),
                  createBaseVNode("div", _hoisted_29, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(rejected.value, (r) => {
                      var _a2, _b;
                      return openBlock(), createElementBlock("button", {
                        key: r.ev,
                        class: "evbtn bad",
                        disabled: busy.value === r.ev || r.trigger.includes("worker") && !((_a2 = order.value) == null ? void 0 : _a2.workerId),
                        onClick: ($event) => push(r.ev)
                      }, [
                        createBaseVNode("span", _hoisted_31, toDisplayString(labelOf(r.ev)), 1),
                        createBaseVNode("span", _hoisted_32, toDisplayString(r.ev) + " · " + toDisplayString(r.trigger.includes("worker") && !((_b = order.value) == null ? void 0 : _b.workerId) ? "这单还没派师傅：只会得到 403" : "状态机说这条边不存在"), 1)
                      ], 8, _hoisted_30);
                    }), 128))
                  ]),
                  _cache[13] || (_cache[13] = createBaseVNode("div", { class: "panel-foot" }, " 409 = 状态机说这条边不存在；403 = 你这个身份不能调这个接口；422 = 边有，但前置条件不满足。三种错不能混。 ", -1))
                ]),
                result.value ? (openBlock(), createElementBlock("section", {
                  key: 0,
                  class: normalizeClass(["panel res", result.value.ok ? "ok" : "bad"])
                }, [
                  createBaseVNode("header", null, [
                    createBaseVNode("b", null, toDisplayString(result.value.title), 1),
                    _cache[14] || (_cache[14] = createBaseVNode("span", { class: "spacer" }, null, -1)),
                    createBaseVNode("span", _hoisted_33, "HTTP " + toDisplayString(result.value.code), 1)
                  ]),
                  createBaseVNode("div", _hoisted_34, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(result.value.lines, (l, i) => {
                      return openBlock(), createElementBlock("p", {
                        key: i,
                        class: "rl"
                      }, toDisplayString(l), 1);
                    }), 128))
                  ])
                ], 2)) : createCommentVNode("", true)
              ]),
              createBaseVNode("div", _hoisted_35, [
                createBaseVNode("section", _hoisted_36, [
                  createBaseVNode("header", null, [
                    _cache[15] || (_cache[15] = createBaseVNode("b", null, "全表自检", -1)),
                    _cache[16] || (_cache[16] = createBaseVNode("span", { class: "spacer" }, null, -1)),
                    createBaseVNode("span", _hoisted_37, toDisplayString(matrix.value.total) + " 种组合 · 合法 " + toDisplayString(matrix.value.legal) + " 条", 1)
                  ]),
                  createBaseVNode("div", _hoisted_38, [
                    createBaseVNode("div", _hoisted_39, [
                      createBaseVNode("table", _hoisted_40, [
                        createBaseVNode("thead", null, [
                          createBaseVNode("tr", null, [
                            _cache[17] || (_cache[17] = createBaseVNode("th", { class: "sticky" }, "从 \\ 事件", -1)),
                            (openBlock(true), createElementBlock(Fragment, null, renderList(((_a = matrix.value.rows[0]) == null ? void 0 : _a.cells) || [], (e) => {
                              return openBlock(), createElementBlock("th", {
                                key: e.event
                              }, [
                                createBaseVNode("span", null, toDisplayString(e.event), 1)
                              ]);
                            }), 128))
                          ])
                        ]),
                        createBaseVNode("tbody", null, [
                          (openBlock(true), createElementBlock(Fragment, null, renderList(matrix.value.rows, (r) => {
                            return openBlock(), createElementBlock("tr", {
                              key: r.from
                            }, [
                              createBaseVNode("th", _hoisted_41, [
                                createTextVNode(toDisplayString(stLabel(r.from)), 1),
                                createBaseVNode("i", null, toDisplayString(r.from), 1)
                              ]),
                              (openBlock(true), createElementBlock(Fragment, null, renderList(r.cells, (c) => {
                                return openBlock(), createElementBlock("td", {
                                  key: c.event,
                                  class: normalizeClass({ ok: c.legal })
                                }, [
                                  c.legal ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                                    createTextVNode("→ " + toDisplayString(stLabel(c.to)), 1)
                                  ], 64)) : createCommentVNode("", true)
                                ], 2);
                              }), 128))
                            ]);
                          }), 128))
                        ])
                      ])
                    ])
                  ]),
                  createBaseVNode("div", _hoisted_42, " 绿色是能走通的。其余 " + toDisplayString(matrix.value.total - matrix.value.legal) + " 种一律拒绝，返回 HTTP 409 —— 页面不自己判，全看这张表。 ", 1)
                ]),
                createBaseVNode("section", _hoisted_43, [
                  _cache[19] || (_cache[19] = createBaseVNode("header", null, [
                    createBaseVNode("b", null, "13 条合法转移"),
                    createBaseVNode("span", { class: "spacer" }),
                    createBaseVNode("span", { class: "hint" }, "SYS-004 第五条")
                  ], -1)),
                  createBaseVNode("div", _hoisted_44, [
                    createBaseVNode("table", _hoisted_45, [
                      _cache[18] || (_cache[18] = createBaseVNode("thead", null, [
                        createBaseVNode("tr", null, [
                          createBaseVNode("th", null, "#"),
                          createBaseVNode("th", null, "从"),
                          createBaseVNode("th", null, "事件"),
                          createBaseVNode("th", null, "到"),
                          createBaseVNode("th", null, "谁来触发")
                        ])
                      ], -1)),
                      createBaseVNode("tbody", null, [
                        (openBlock(true), createElementBlock(Fragment, null, renderList(transitions.value, (t, i) => {
                          return openBlock(), createElementBlock("tr", {
                            key: t.event + t.from
                          }, [
                            createBaseVNode("td", _hoisted_46, toDisplayString(i + 1), 1),
                            createBaseVNode("td", null, toDisplayString(stLabel(t.from)), 1),
                            createBaseVNode("td", _hoisted_47, [
                              createTextVNode(toDisplayString(labelOf(t.event)), 1),
                              createBaseVNode("i", null, toDisplayString(t.event), 1)
                            ]),
                            createBaseVNode("td", null, toDisplayString(stLabel(t.to)), 1),
                            createBaseVNode("td", _hoisted_48, toDisplayString((t.trigger || []).join(" / ")), 1)
                          ]);
                        }), 128))
                      ])
                    ])
                  ])
                ])
              ])
            ])
          ])
        ])
      ]);
    };
  }
};
const Lab = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-7e153d06"]]);
export {
  Lab as default
};
