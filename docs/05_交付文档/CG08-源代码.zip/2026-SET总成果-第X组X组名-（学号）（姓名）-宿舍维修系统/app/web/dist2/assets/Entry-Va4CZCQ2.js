import { o as onMounted, c as createElementBlock, a as createBaseVNode, u as unref, b as createTextVNode, t as toDisplayString, d as createCommentVNode, F as Fragment, r as renderList, e as useRouter, f as ref, g as openBlock } from "./index-CQHsh9DN.js";
import { _ as _export_sfc, o as ordersApi, d as describeError } from "./_plugin-vue_export-helper-CJxN7Dmm.js";
const _hoisted_1 = { class: "launch" };
const _hoisted_2 = { class: "hd" };
const _hoisted_3 = {
  key: 0,
  class: "err"
};
const _hoisted_4 = { class: "kpis" };
const _hoisted_5 = { class: "n num" };
const _hoisted_6 = { class: "n num" };
const _hoisted_7 = { class: "n num" };
const _hoisted_8 = { class: "ends" };
const _hoisted_9 = { class: "eh" };
const _hoisted_10 = ["data-d"];
const _hoisted_11 = { class: "sub" };
const _hoisted_12 = ["onClick"];
const _hoisted_13 = { class: "tools" };
const _hoisted_14 = ["disabled"];
const _hoisted_15 = ["disabled"];
const _hoisted_16 = ["disabled"];
const _hoisted_17 = { class: "rule" };
const _sfc_main = {
  __name: "Entry",
  setup(__props) {
    const router = useRouter();
    const stats = ref({ orders: "—", zero: "—", exceptions: "—" });
    const err = ref("");
    const busy = ref("");
    const ENDS = [
      {
        to: "/student",
        device: "phone",
        title: "学生端",
        sub: "手机 · 430 宽",
        points: ["拍一张、说一句就报修", "不用选紧急程度，系统判", "全程看到师傅在哪一步"]
      },
      {
        to: "/worker",
        device: "phone",
        title: "师傅端",
        sub: "手机 · 430 宽",
        points: ["按楼栋跑，楼层从高到低", "进楼打卡一次，一批单一起记到门", "缺件填金额，超预算自动上审批"]
      },
      {
        to: "/admin",
        device: "desk",
        title: "管理端",
        sub: "电脑 · 1440 宽",
        points: ["不派工、不审批、不催办", "只看四类例外", "零人工完成率与返修率两个数"]
      }
    ];
    async function load() {
      var _a;
      try {
        const [dash, ex] = await Promise.all([ordersApi.dashboard(), ordersApi.exceptions()]);
        stats.value = {
          orders: dash.active + dash.pendingArchive,
          zero: `${Math.round((((_a = dash.zeroManual) == null ? void 0 : _a.rate) ?? 0) * 100)}%`,
          exceptions: ex.total
        };
      } catch (e) {
        err.value = describeError(e);
      }
    }
    async function advance(hours) {
      busy.value = `advance${hours}`;
      err.value = "";
      try {
        await ordersApi.advance(hours);
        await load();
      } catch (e) {
        err.value = describeError(e);
      } finally {
        busy.value = "";
      }
    }
    async function reset() {
      busy.value = "reset";
      err.value = "";
      try {
        await ordersApi.reset();
        await load();
      } catch (e) {
        err.value = describeError(e);
      } finally {
        busy.value = "";
      }
    }
    onMounted(load);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("header", _hoisted_2, [
          _cache[5] || (_cache[5] = createBaseVNode("div", { class: "logo" }, "修", -1)),
          _cache[6] || (_cache[6] = createBaseVNode("div", null, [
            createBaseVNode("div", { class: "t" }, "宿舍维修系统"),
            createBaseVNode("div", { class: "s" }, "示范大学 · 后勤维修部 · V5.0")
          ], -1)),
          _cache[7] || (_cache[7] = createBaseVNode("div", { class: "sp" }, null, -1)),
          createBaseVNode("button", {
            class: "link",
            onClick: _cache[0] || (_cache[0] = ($event) => unref(router).push("/admin"))
          }, "进管理端 ›")
        ]),
        _cache[18] || (_cache[18] = createBaseVNode("section", { class: "hero" }, [
          createBaseVNode("h1", null, [
            createTextVNode("拍一张、说一句，"),
            createBaseVNode("em", null, "剩下的它自己跑。")
          ]),
          createBaseVNode("p", null, [
            createTextVNode(" 学生的报修进来自动定级、自动派给本楼师傅；师傅按楼层跑楼、缺件当场登记；"),
            createBaseVNode("br"),
            createTextVNode(" 管理端不进流程，只在四类例外里出手。"),
            createBaseVNode("br"),
            createTextVNode(" 一条链走完不用任何人点头，这就是这套东西要证明的事。 ")
          ])
        ], -1)),
        err.value ? (openBlock(), createElementBlock("p", _hoisted_3, toDisplayString(err.value), 1)) : createCommentVNode("", true),
        createBaseVNode("div", _hoisted_4, [
          createBaseVNode("div", null, [
            createBaseVNode("div", _hoisted_5, toDisplayString(stats.value.orders), 1),
            _cache[8] || (_cache[8] = createBaseVNode("div", { class: "k" }, "在办与待归档", -1))
          ]),
          _cache[11] || (_cache[11] = createBaseVNode("div", null, [
            createBaseVNode("div", { class: "n num" }, "13"),
            createBaseVNode("div", { class: "k" }, "条合法转移（共 130 种组合）")
          ], -1)),
          createBaseVNode("div", null, [
            createBaseVNode("div", _hoisted_6, toDisplayString(stats.value.zero), 1),
            _cache[9] || (_cache[9] = createBaseVNode("div", { class: "k" }, "零人工完成率", -1))
          ]),
          createBaseVNode("div", null, [
            createBaseVNode("div", _hoisted_7, toDisplayString(stats.value.exceptions), 1),
            _cache[10] || (_cache[10] = createBaseVNode("div", { class: "k" }, "例外待看", -1))
          ])
        ]),
        createBaseVNode("div", _hoisted_8, [
          (openBlock(), createElementBlock(Fragment, null, renderList(ENDS, (e) => {
            return createBaseVNode("article", {
              key: e.to,
              class: "end"
            }, [
              createBaseVNode("div", _hoisted_9, [
                createBaseVNode("span", {
                  class: "dev",
                  "data-d": e.device
                }, toDisplayString(e.device === "desk" ? "电脑" : "手机"), 9, _hoisted_10),
                createBaseVNode("span", _hoisted_11, toDisplayString(e.sub), 1)
              ]),
              createBaseVNode("h3", null, toDisplayString(e.title), 1),
              createBaseVNode("ul", null, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(e.points, (p) => {
                  return openBlock(), createElementBlock("li", { key: p }, toDisplayString(p), 1);
                }), 128))
              ]),
              createBaseVNode("button", {
                class: "go",
                onClick: ($event) => unref(router).push(e.to)
              }, "进入 ›", 8, _hoisted_12)
            ]);
          }), 64))
        ]),
        createBaseVNode("div", _hoisted_13, [
          createBaseVNode("button", {
            class: "tool",
            onClick: _cache[1] || (_cache[1] = ($event) => unref(router).push("/lab"))
          }, [..._cache[12] || (_cache[12] = [
            createBaseVNode("b", null, "状态机自检台", -1),
            createBaseVNode("span", null, "选一张单，推一条边，看 409 现场怎么拒", -1)
          ])]),
          createBaseVNode("button", {
            class: "tool",
            disabled: busy.value === "advance168",
            onClick: _cache[2] || (_cache[2] = ($event) => advance(168))
          }, [..._cache[13] || (_cache[13] = [
            createBaseVNode("b", null, "快进 168 小时", -1),
            createBaseVNode("span", null, "让待验收的单超时自动验收", -1)
          ])], 8, _hoisted_14),
          createBaseVNode("button", {
            class: "tool",
            disabled: busy.value === "advance336",
            onClick: _cache[3] || (_cache[3] = ($event) => advance(336))
          }, [..._cache[14] || (_cache[14] = [
            createBaseVNode("b", null, "再快进 168 小时", -1),
            createBaseVNode("span", null, "让已完成的单满 7 天自动归档", -1)
          ])], 8, _hoisted_15),
          createBaseVNode("button", {
            class: "tool",
            disabled: busy.value === "reset",
            onClick: reset
          }, [..._cache[15] || (_cache[15] = [
            createBaseVNode("b", null, "重置演示数据", -1),
            createBaseVNode("span", null, "清空重灌一套，回到 7 张单", -1)
          ])], 8, _hoisted_16)
        ]),
        createBaseVNode("div", _hoisted_17, [
          _cache[16] || (_cache[16] = createBaseVNode("b", null, "规矩", -1)),
          _cache[17] || (_cache[17] = createBaseVNode("span", null, "9 个状态、13 条转移。没这条边就是 409，前置不满足是 422，身份不对是 403 —— 三种错不能混着返回。", -1)),
          createBaseVNode("button", {
            class: "link",
            onClick: _cache[4] || (_cache[4] = ($event) => unref(router).push("/lab"))
          }, "看全表 ›")
        ]),
        _cache[19] || (_cache[19] = createBaseVNode("footer", { class: "ft" }, " 学生端与师傅端是手机页（430 宽），管理端与自检台是桌面页 —— 这是产品定位，不是样式偏好。 ", -1))
      ]);
    };
  }
};
const Entry = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-25a3f7b1"]]);
export {
  Entry as default
};
