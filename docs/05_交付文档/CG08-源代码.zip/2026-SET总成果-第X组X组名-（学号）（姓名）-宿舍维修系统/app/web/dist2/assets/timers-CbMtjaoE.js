function parseAt(s) {
  if (!s) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/.exec(String(s).trim());
  if (!m) return null;
  return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0)).getTime();
}
function timersOf(o, meta) {
  const out = { t1: null, t2: null, stayedMs: null };
  if (!o) return out;
  const now = Date.now();
  if (o.status === "VERIFYING" && o.finishAt) {
    const from = parseAt(o.finishAt);
    const total = ((meta == null ? void 0 : meta.verifyHours) ?? 168) * 3600 * 1e3;
    if (from) out.t1 = { from: o.finishAt, deadline: from + total, leftMs: from + total - now, total, label: "验收倒计时" };
  }
  if (o.status === "DONE" && o.signAt) {
    const from = parseAt(o.signAt);
    const total = ((meta == null ? void 0 : meta.archiveDays) ?? 7) * 24 * 3600 * 1e3;
    if (from) out.t2 = { from: o.signAt, deadline: from + total, leftMs: from + total - now, total, label: "归档倒计时" };
  }
  const base = parseAt(o.statusAt || o.createdAt);
  if (base) out.stayedMs = now - base;
  return out;
}
function toneOf(leftMs, total) {
  if (leftMs === null || leftMs === void 0) return "";
  if (leftMs <= 0) return "bad";
  if (total && leftMs < total * 0.25) return "warn";
  return "";
}
export {
  timersOf as a,
  toneOf as t
};
