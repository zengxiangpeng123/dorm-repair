import { o as onMounted, c as createElementBlock, a as createBaseVNode, u as unref, t as toDisplayString, F as Fragment, r as renderList, d as createCommentVNode, w as withDirectives, v as vModelText, i as createVNode, k as withModifiers, e as useRouter, f as ref, j as computed, g as openBlock, n as normalizeClass } from "./index-CQHsh9DN.js";
import { B as BottomNav } from "./BottomNav-wi4vEY3F.js";
import { _ as _sfc_main$1 } from "./StatusPill-KCmlmcRf.js";
import { _ as _sfc_main$2 } from "./LevelPill-ZCCnoTlp.js";
import { _ as _export_sfc, a as actorOf, o as ordersApi, d as describeError } from "./_plugin-vue_export-helper-CJxN7Dmm.js";
import { b as shortWindow } from "./status-BDo8bc0j.js";
const _hoisted_1 = { class: "top" };
const _hoisted_2 = { class: "tiny muted" };
const _hoisted_3 = { class: "body" };
const _hoisted_4 = { class: "card" };
const _hoisted_5 = {
  key: 0,
  class: "thumbs"
};
const _hoisted_6 = ["onClick"];
const _hoisted_7 = { class: "card" };
const _hoisted_8 = { class: "card-hd" };
const _hoisted_9 = { class: "hint" };
const _hoisted_10 = { class: "card" };
const _hoisted_11 = { class: "seg" };
const _hoisted_12 = ["onClick"];
const _hoisted_13 = {
  class: "kv",
  style: { "margin-top": "11px" }
};
const _hoisted_14 = { class: "v" };
const _hoisted_15 = {
  key: 0,
  class: "err"
};
const _hoisted_16 = ["disabled"];
const _hoisted_17 = { class: "sheet" };
const _hoisted_18 = { class: "sheet-hd" };
const _hoisted_19 = { class: "ok-no num" };
const _hoisted_20 = {
  class: "row",
  style: { "margin": "6px 0 12px" }
};
const _hoisted_21 = { class: "pill plain" };
const _hoisted_22 = { class: "kv" };
const _hoisted_23 = { class: "v" };
const _hoisted_24 = { class: "kv" };
const _hoisted_25 = { class: "v" };
const _hoisted_26 = {
  key: 0,
  class: "kv"
};
const _hoisted_27 = { class: "v" };
const _hoisted_28 = {
  key: 1,
  class: "note",
  "data-tone": "warn",
  style: { "margin-top": "10px" }
};
const _sfc_main = {
  __name: "New",
  setup(__props) {
    const router = useRouter();
    const me = actorOf("student");
    const meta = ref(null);
    const photos = ref([]);
    const desc = ref("");
    const window = ref("");
    const busy = ref(false);
    const err = ref("");
    const done = ref(null);
    const windows = computed(() => {
      var _a;
      return ((_a = meta.value) == null ? void 0 : _a.windows) || [];
    });
    const canSubmit = computed(() => photos.value.length > 0 && desc.value.trim().length >= 4 && !busy.value);
    onMounted(async () => {
      try {
        meta.value = await ordersApi.meta();
        window.value = windows.value[0] || "";
      } catch (e) {
        err.value = e.message;
      }
    });
    function shoot() {
      if (photos.value.length >= 3) return;
      photos.value.push(`demo://before/${me.id}/${Date.now()}-${photos.value.length + 1}.jpg`);
    }
    function remove(i) {
      photos.value.splice(i, 1);
    }
    async function submit() {
      if (!canSubmit.value) return;
      busy.value = true;
      err.value = "";
      try {
        const created = await ordersApi.submit({
          building: me.building,
          floor: Number(me.room[0]),
          room: me.room,
          desc: desc.value.trim(),
          window: window.value,
          photosBefore: photos.value
        });
        let view = created;
        try {
          view = await ordersApi.assign(created.no, { version: created.version }, { role: "system" });
        } catch (e) {
          view = { ...created, assignError: describeError(e) };
        }
        done.value = view;
      } catch (e) {
        err.value = describeError(e);
      } finally {
        busy.value = false;
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("header", _hoisted_1, [
          createBaseVNode("button", {
            class: "back",
            onClick: _cache[0] || (_cache[0] = ($event) => unref(router).back())
          }, "‹ 返回"),
          _cache[5] || (_cache[5] = createBaseVNode("b", null, "报修", -1)),
          createBaseVNode("span", _hoisted_2, toDisplayString(unref(me).building) + " " + toDisplayString(unref(me).room), 1)
        ]),
        createBaseVNode("div", _hoisted_3, [
          createBaseVNode("div", _hoisted_4, [
            _cache[8] || (_cache[8] = createBaseVNode("div", { class: "card-hd" }, [
              createBaseVNode("h3", null, "① 拍一张"),
              createBaseVNode("span", { class: "hint" }, "必填，至少 1 张")
            ], -1)),
            createBaseVNode("button", {
              class: "uploader",
              onClick: shoot
            }, [..._cache[6] || (_cache[6] = [
              createBaseVNode("div", { style: { "font-size": "20px" } }, "📷", -1),
              createBaseVNode("div", { style: { "margin-top": "4px" } }, "点一下，拍下坏的地方", -1),
              createBaseVNode("div", {
                class: "tiny",
                style: { "margin-top": "2px" }
              }, "最多 3 张", -1)
            ])]),
            photos.value.length ? (openBlock(), createElementBlock("div", _hoisted_5, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(photos.value, (p, i) => {
                return openBlock(), createElementBlock("div", {
                  key: p,
                  class: "thumb",
                  "data-tone": "ok",
                  onClick: ($event) => remove(i)
                }, [
                  _cache[7] || (_cache[7] = createBaseVNode("span", null, "📷", -1)),
                  createBaseVNode("span", null, "第 " + toDisplayString(i + 1) + " 张", 1)
                ], 8, _hoisted_6);
              }), 128))
            ])) : createCommentVNode("", true)
          ]),
          createBaseVNode("div", _hoisted_7, [
            createBaseVNode("div", _hoisted_8, [
              _cache[9] || (_cache[9] = createBaseVNode("h3", null, "② 说一句", -1)),
              createBaseVNode("span", _hoisted_9, toDisplayString(desc.value.trim().length) + " 字", 1)
            ]),
            withDirectives(createBaseVNode("textarea", {
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => desc.value = $event),
              rows: "4",
              maxlength: "200",
              class: "ta",
              placeholder: "举个例子：洗手台下面一直滴水，水桶快接满了"
            }, null, 512), [
              [vModelText, desc.value]
            ]),
            _cache[10] || (_cache[10] = createBaseVNode("div", {
              class: "note",
              "data-tone": "info",
              style: { "margin-top": "9px" }
            }, " 紧急程度不用你选。系统看描述自动判故障类型和紧急程度，判不准就往急里判，判完把依据写在这张单上，你可以查。 ", -1))
          ]),
          createBaseVNode("div", _hoisted_10, [
            _cache[12] || (_cache[12] = createBaseVNode("div", { class: "card-hd" }, [
              createBaseVNode("h3", null, "③ 什么时候有人"),
              createBaseVNode("span", { class: "hint" }, "选填")
            ], -1)),
            createBaseVNode("div", _hoisted_11, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(windows.value, (w) => {
                return openBlock(), createElementBlock("button", {
                  key: w,
                  class: normalizeClass({ on: window.value === w }),
                  onClick: ($event) => window.value = window.value === w ? "" : w
                }, toDisplayString(unref(shortWindow)(w)), 11, _hoisted_12);
              }), 128))
            ]),
            createBaseVNode("div", _hoisted_13, [
              _cache[11] || (_cache[11] = createBaseVNode("span", { class: "k" }, "位置", -1)),
              createBaseVNode("span", _hoisted_14, toDisplayString(unref(me).building === "B7" ? "东区7号楼" : "东区8号楼") + " " + toDisplayString(unref(me).room) + " 室 · 按学籍带出，不用填", 1)
            ])
          ]),
          err.value ? (openBlock(), createElementBlock("p", _hoisted_15, toDisplayString(err.value), 1)) : createCommentVNode("", true),
          createBaseVNode("button", {
            class: "submit",
            disabled: !canSubmit.value,
            onClick: submit
          }, toDisplayString(busy.value ? "提交中…" : "提交报修"), 9, _hoisted_16),
          _cache[13] || (_cache[13] = createBaseVNode("p", { class: "tiny muted center" }, "提交后自动派给本楼当班师傅，你可以在「我的报修」里看到每一步。", -1))
        ]),
        createVNode(BottomNav, { role: "student" }),
        done.value ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: "mask",
          onClick: _cache[4] || (_cache[4] = withModifiers(($event) => unref(router).push("/student"), ["self"]))
        }, [
          createBaseVNode("div", _hoisted_17, [
            createBaseVNode("div", _hoisted_18, [
              _cache[14] || (_cache[14] = createBaseVNode("b", null, "报好了", -1)),
              createBaseVNode("button", {
                onClick: _cache[2] || (_cache[2] = ($event) => unref(router).push("/student"))
              }, "知道了")
            ]),
            createBaseVNode("div", _hoisted_19, toDisplayString(done.value.no), 1),
            createBaseVNode("div", _hoisted_20, [
              createVNode(_sfc_main$1, {
                status: done.value.status
              }, null, 8, ["status"]),
              createVNode(_sfc_main$2, {
                level: done.value.level
              }, null, 8, ["level"]),
              createBaseVNode("span", _hoisted_21, toDisplayString(done.value.category), 1)
            ]),
            createBaseVNode("div", _hoisted_22, [
              _cache[15] || (_cache[15] = createBaseVNode("span", { class: "k" }, "谁上门", -1)),
              createBaseVNode("span", _hoisted_23, toDisplayString(done.value.worker ? `${done.value.worker.name}` : "等派工"), 1)
            ]),
            createBaseVNode("div", _hoisted_24, [
              _cache[16] || (_cache[16] = createBaseVNode("span", { class: "k" }, "时段", -1)),
              createBaseVNode("span", _hoisted_25, toDisplayString(unref(shortWindow)(done.value.window) || "全天"), 1)
            ]),
            done.value.aiBasis ? (openBlock(), createElementBlock("div", _hoisted_26, [
              _cache[17] || (_cache[17] = createBaseVNode("span", { class: "k" }, "系统怎么判", -1)),
              createBaseVNode("span", _hoisted_27, toDisplayString(done.value.aiBasis), 1)
            ])) : createCommentVNode("", true),
            done.value.assignError ? (openBlock(), createElementBlock("p", _hoisted_28, toDisplayString(done.value.assignError), 1)) : createCommentVNode("", true),
            createBaseVNode("button", {
              class: "submit",
              style: { "margin-top": "14px" },
              onClick: _cache[3] || (_cache[3] = ($event) => unref(router).push(`/student/detail/${done.value.no}`))
            }, "看这单进度")
          ])
        ])) : createCommentVNode("", true)
      ], 64);
    };
  }
};
const New = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-826b2118"]]);
export {
  New as default
};
