import { o as onMounted, c as createElementBlock, a as createBaseVNode, u as unref, t as toDisplayString, d as createCommentVNode, F as Fragment, r as renderList, i as createVNode, e as useRouter, f as ref, j as computed, g as openBlock } from "./index-CQHsh9DN.js";
import { B as BottomNav } from "./BottomNav-wi4vEY3F.js";
import { _ as _sfc_main$1 } from "./Plate-3npaODG1.js";
import { _ as _sfc_main$2 } from "./StatusPill-KCmlmcRf.js";
import { _ as _export_sfc, a as actorOf, o as ordersApi, d as describeError } from "./_plugin-vue_export-helper-CJxN7Dmm.js";
import { b as shortWindow, W as WALK_STATUS } from "./status-BDo8bc0j.js";
const _hoisted_1 = { class: "top" };
const _hoisted_2 = { class: "tiny muted" };
const _hoisted_3 = { class: "body has-dock" };
const _hoisted_4 = {
  key: 0,
  class: "err"
};
const _hoisted_5 = {
  key: 1,
  class: "note",
  "data-tone": "warn"
};
const _hoisted_6 = {
  key: 2,
  class: "note",
  "data-tone": "ok"
};
const _hoisted_7 = { class: "floor-h" };
const _hoisted_8 = ["data-st", "onClick"];
const _hoisted_9 = { class: "tx" };
const _hoisted_10 = { class: "r1" };
const _hoisted_11 = { class: "r2" };
const _hoisted_12 = { class: "r3" };
const _hoisted_13 = {
  key: 3,
  class: "empty-mini"
};
const _hoisted_14 = {
  key: 4,
  class: "tiny muted",
  style: { "margin-top": "10px" }
};
const _hoisted_15 = {
  key: 5,
  class: "card empty"
};
const _hoisted_16 = { class: "dock" };
const _hoisted_17 = ["disabled"];
const _hoisted_18 = {
  key: 0,
  class: "toast"
};
const _sfc_main = {
  __name: "Building",
  setup(__props) {
    const router = useRouter();
    const me = actorOf("worker");
    const board = ref(null);
    const meta = ref(null);
    const loading = ref(true);
    const err = ref("");
    const busy = ref(false);
    const toast = ref("");
    let toastTimer = null;
    const all = computed(() => {
      var _a;
      return (((_a = board.value) == null ? void 0 : _a.floors) || []).flatMap((f) => f.orders || []);
    });
    const arrived = computed(() => all.value.some((o) => o.arriveAt));
    const floors = computed(
      () => {
        var _a;
        return (((_a = board.value) == null ? void 0 : _a.floors) || []).map((f) => ({ floor: f.floor, orders: (f.orders || []).filter((o) => WALK_STATUS.includes(o.status)) })).filter((f) => f.orders.length);
      }
    );
    const other = computed(() => all.value.filter((o) => !WALK_STATUS.includes(o.status)).length);
    const count = computed(() => floors.value.reduce((n, f) => n + f.orders.length, 0));
    function tone(o) {
      return o.status;
    }
    async function load() {
      try {
        const m = meta.value || await ordersApi.meta();
        meta.value = m;
        const b = m.buildings.find((x) => x.id === me.building) || m.buildings[0];
        board.value = await ordersApi.board(b.id, b.floors);
        err.value = "";
      } catch (e) {
        err.value = describeError(e);
      } finally {
        loading.value = false;
      }
    }
    async function arriveBatch() {
      busy.value = true;
      err.value = "";
      try {
        const r = await ordersApi.arriveBuilding(me.building, {}, { role: "worker" });
        toast.value = `已打卡 ${(r.ok || []).length} 单${(r.skipped || []).length ? `，${(r.skipped || []).length} 单跳过` : ""}`;
        window.clearTimeout(toastTimer);
        toastTimer = window.setTimeout(() => {
          toast.value = "";
        }, 2600);
        await load();
      } catch (e) {
        err.value = describeError(e);
      } finally {
        busy.value = false;
      }
    }
    onMounted(load);
    return (_ctx, _cache) => {
      var _a, _b, _c;
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("header", _hoisted_1, [
          createBaseVNode("button", {
            class: "back",
            onClick: _cache[0] || (_cache[0] = ($event) => unref(router).push("/worker"))
          }, "‹ 工作台"),
          createBaseVNode("b", null, toDisplayString(((_a = board.value) == null ? void 0 : _a.buildingName) || "本楼"), 1),
          createBaseVNode("span", _hoisted_2, toDisplayString(count.value) + " 单要上楼", 1)
        ]),
        createBaseVNode("div", _hoisted_3, [
          err.value ? (openBlock(), createElementBlock("p", _hoisted_4, toDisplayString(err.value), 1)) : createCommentVNode("", true),
          !arrived.value ? (openBlock(), createElementBlock("div", _hoisted_5, " 还没进楼。到楼门口点下面的按钮，这一批单一起记「到门」。 ")) : (openBlock(), createElementBlock("div", _hoisted_6, "已在楼内 · 按楼层从高往低走，一层一层来。")),
          (openBlock(true), createElementBlock(Fragment, null, renderList(floors.value, (f) => {
            return openBlock(), createElementBlock("div", {
              key: f.floor
            }, [
              createBaseVNode("div", _hoisted_7, [
                createBaseVNode("b", null, toDisplayString(f.floor) + "F", 1),
                createBaseVNode("span", null, toDisplayString(f.orders.length) + " 间", 1)
              ]),
              (openBlock(true), createElementBlock(Fragment, null, renderList(f.orders, (o) => {
                return openBlock(), createElementBlock("div", {
                  key: o.no,
                  class: "ticket",
                  "data-st": tone(o),
                  onClick: ($event) => unref(router).push(`/worker/task/${o.no}`)
                }, [
                  createVNode(_sfc_main$1, {
                    room: o.room,
                    floor: o.floor,
                    status: o.status
                  }, null, 8, ["room", "floor", "status"]),
                  createBaseVNode("div", _hoisted_9, [
                    createBaseVNode("div", _hoisted_10, [
                      createBaseVNode("b", null, toDisplayString(o.room) + " 室", 1),
                      createVNode(_sfc_main$2, {
                        status: o.status
                      }, null, 8, ["status"])
                    ]),
                    createBaseVNode("div", _hoisted_11, toDisplayString(o.desc), 1),
                    createBaseVNode("div", _hoisted_12, toDisplayString(o.studentName) + " · " + toDisplayString(unref(shortWindow)(o.window) || "全天") + " · " + toDisplayString(o.category), 1)
                  ])
                ], 8, _hoisted_8);
              }), 128))
            ]);
          }), 128)),
          ((_c = (_b = board.value) == null ? void 0 : _b.emptyFloors) == null ? void 0 : _c.length) ? (openBlock(), createElementBlock("div", _hoisted_13, toDisplayString(board.value.emptyFloors.map((n) => n + "F").join("、")) + " 本层没有单，不用上去 ", 1)) : createCommentVNode("", true),
          other.value ? (openBlock(), createElementBlock("div", _hoisted_14, " 另有 " + toDisplayString(other.value) + " 单在等学生验收或返修，不用上楼。 ", 1)) : createCommentVNode("", true),
          !loading.value && !count.value ? (openBlock(), createElementBlock("div", _hoisted_15, "本楼没有要上楼的活。")) : createCommentVNode("", true)
        ]),
        createBaseVNode("div", _hoisted_16, [
          !arrived.value ? (openBlock(), createElementBlock("button", {
            key: 0,
            class: "dbtn primary",
            disabled: busy.value,
            onClick: arriveBatch
          }, toDisplayString(busy.value ? "打卡中…" : "进楼打卡"), 9, _hoisted_17)) : (openBlock(), createElementBlock("button", {
            key: 1,
            class: "dbtn",
            onClick: _cache[1] || (_cache[1] = ($event) => unref(router).push("/worker"))
          }, "回工作台"))
        ]),
        toast.value ? (openBlock(), createElementBlock("div", _hoisted_18, toDisplayString(toast.value), 1)) : createCommentVNode("", true),
        createVNode(BottomNav, { role: "worker" })
      ], 64);
    };
  }
};
const Building = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-40ad36bf"]]);
export {
  Building as default
};
