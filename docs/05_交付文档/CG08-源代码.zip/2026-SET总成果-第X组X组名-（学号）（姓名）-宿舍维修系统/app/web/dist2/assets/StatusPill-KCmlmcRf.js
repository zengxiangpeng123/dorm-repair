import { S as STATUS } from "./status-BDo8bc0j.js";
import { g as openBlock, c as createElementBlock, t as toDisplayString, u as unref, n as normalizeClass } from "./index-CQHsh9DN.js";
const _hoisted_1 = ["data-st"];
const _sfc_main = {
  __name: "StatusPill",
  props: { status: { type: String, required: true }, plain: Boolean },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("span", {
        class: normalizeClass(["pill", { plain: __props.plain }]),
        "data-st": __props.status
      }, toDisplayString(unref(STATUS)[__props.status] || __props.status), 11, _hoisted_1);
    };
  }
};
export {
  _sfc_main as _
};
