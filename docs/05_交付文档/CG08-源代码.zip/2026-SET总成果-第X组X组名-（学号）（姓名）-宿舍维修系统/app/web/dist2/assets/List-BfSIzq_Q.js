import { f as ref, o as onMounted, c as createElementBlock, a as createBaseVNode, t as toDisplayString, F as Fragment, r as renderList, d as createCommentVNode, i as createVNode, l as useRoute, j as computed, e as useRouter, g as openBlock, n as normalizeClass, u as unref, b as createTextVNode } from "./index-CQHsh9DN.js";
import { B as BottomNav } from "./BottomNav-wi4vEY3F.js";
import { _ as _sfc_main$1 } from "./StatusPill-KCmlmcRf.js";
import { _ as _export_sfc, o as ordersApi } from "./_plugin-vue_export-helper-CJxN7Dmm.js";
import { s as shortLeft } from "./status-BDo8bc0j.js";
const _hoisted_1 = { class: "top" };
const _hoisted_2 = { class: "tiny muted" };
const _hoisted_3 = { class: "body" };
const _hoisted_4 = { class: "seg" };
const _hoisted_5 = ["onClick"];
const _hoisted_6 = {
  key: 0,
  class: "err"
};
const _hoisted_7 = { style: { "margin-top": "12px" } };
const _hoisted_8 = ["data-st", "onClick"];
const _hoisted_9 = { class: "tx" };
const _hoisted_10 = { class: "r1" };
const _hoisted_11 = { class: "r2" };
const _hoisted_12 = { class: "r3" };
const _hoisted_13 = {
  key: 0,
  class: "r4"
};
const _hoisted_14 = {
  key: 0,
  class: "card empty"
};
const _sfc_main = {
  __name: "List",
  setup(__props) {
    const route = useRoute();
    const router = useRouter();
    const tab = ref(route.query.tab || "ACTIVE");
    const all = ref([]);
    const loading = ref(true);
    const err = ref("");
    const TABS = [
      { key: "ACTIVE", label: "进行中" },
      { key: "DONE", label: "已完工" },
      { key: "ALL", label: "全部" }
    ];
    const counts = computed(() => {
      const c = { ACTIVE: 0, DONE: 0, ALL: all.value.length };
      for (const o of all.value) {
        if (["PENDING", "ASSIGNED", "REPAIRING", "PARTS", "VERIFYING", "REWORKING"].includes(o.status)) c.ACTIVE++;
        if (o.status === "DONE" || o.status === "CLOSED") c.DONE++;
      }
      return c;
    });
    const rows = computed(() => {
      if (tab.value === "ALL") return all.value;
      if (tab.value === "DONE") return all.value.filter((o) => o.status === "DONE" || o.status === "CLOSED");
      return all.value.filter((o) => ["PENDING", "ASSIGNED", "REPAIRING", "PARTS", "VERIFYING", "REWORKING"].includes(o.status));
    });
    function left(o) {
      const t = o.timers && (o.timers.t1 || o.timers.t2);
      if (!t) return "";
      return `${t.label === "归档倒计时" ? "归档" : "验收"} ${shortLeft(t.leftMs)}`;
    }
    async function load() {
      try {
        const r = await ordersApi.myOrders("ALL");
        all.value = r.items || [];
      } catch (e) {
        err.value = e.message;
      } finally {
        loading.value = false;
      }
    }
    function pick(k) {
      tab.value = k;
      router.replace({ query: { tab: k } });
    }
    onMounted(load);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("header", _hoisted_1, [
          _cache[0] || (_cache[0] = createBaseVNode("b", null, "我的报修", -1)),
          createBaseVNode("span", _hoisted_2, "共 " + toDisplayString(counts.value.ALL) + " 单", 1)
        ]),
        createBaseVNode("div", _hoisted_3, [
          createBaseVNode("div", _hoisted_4, [
            (openBlock(), createElementBlock(Fragment, null, renderList(TABS, (t) => {
              return createBaseVNode("button", {
                key: t.key,
                class: normalizeClass({ on: tab.value === t.key }),
                onClick: ($event) => pick(t.key)
              }, toDisplayString(t.label) + " " + toDisplayString(counts.value[t.key]), 11, _hoisted_5);
            }), 64))
          ]),
          err.value ? (openBlock(), createElementBlock("p", _hoisted_6, toDisplayString(err.value), 1)) : createCommentVNode("", true),
          createBaseVNode("div", _hoisted_7, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(rows.value, (o) => {
              return openBlock(), createElementBlock("div", {
                key: o.no,
                class: "ticket",
                "data-st": o.status,
                onClick: ($event) => unref(router).push(`/student/detail/${o.no}`)
              }, [
                createBaseVNode("div", _hoisted_9, [
                  createBaseVNode("div", _hoisted_10, [
                    createBaseVNode("b", null, toDisplayString(o.building) + " " + toDisplayString(o.floor) + "F-" + toDisplayString(o.room), 1),
                    createVNode(_sfc_main$1, {
                      status: o.status
                    }, null, 8, ["status"])
                  ]),
                  createBaseVNode("div", _hoisted_11, toDisplayString(o.desc), 1),
                  createBaseVNode("div", _hoisted_12, [
                    createTextVNode(toDisplayString(o.no) + " · " + toDisplayString(o.category) + " ", 1),
                    o.reworkOf ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                      createTextVNode(" · 返修 R" + toDisplayString(o.reworkIndex), 1)
                    ], 64)) : createCommentVNode("", true)
                  ]),
                  left(o) ? (openBlock(), createElementBlock("div", _hoisted_13, toDisplayString(left(o)), 1)) : createCommentVNode("", true)
                ])
              ], 8, _hoisted_8);
            }), 128)),
            !loading.value && !rows.value.length ? (openBlock(), createElementBlock("div", _hoisted_14, toDisplayString(tab.value === "DONE" ? "还没有完工的报修" : "这一栏是空的"), 1)) : createCommentVNode("", true)
          ])
        ]),
        createVNode(BottomNav, { role: "student" })
      ], 64);
    };
  }
};
const List = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-140a9383"]]);
export {
  List as default
};
