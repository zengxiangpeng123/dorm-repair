const STATUS = {
  PENDING: "待派工",
  ASSIGNED: "已派工",
  REPAIRING: "维修中",
  PARTS: "待配件",
  VERIFYING: "待验收",
  REWORKING: "返修中",
  DONE: "已完成",
  CLOSED: "已关闭",
  CANCELLED: "已取消"
};
const EVENT = {
  SUBMIT: "提交报修",
  ASSIGN: "派工",
  ARRIVE: "到门打卡",
  NO_SHOW: "到访未遇",
  FINISH: "完工提交",
  NEED_PARTS: "登记缺件",
  PARTS_ARRIVED: "配件到货",
  ACCEPT: "验收通过",
  REJECT: "验收不通过",
  AUTO_ACCEPT: "超时自动验收",
  CANCEL: "学生撤销",
  CANCEL_REQUEST: "申请撤销"
};
const WALK_STATUS = ["PENDING", "ASSIGNED", "REPAIRING", "PARTS"];
function steps(o) {
  const i = { PENDING: 1, ASSIGNED: 2, REPAIRING: 3, PARTS: 3, VERIFYING: 4, REWORKING: 3, DONE: 5, CLOSED: 5, CANCELLED: 0 }[o.status] ?? 0;
  const labels = ["提交报修", "派工", "上门维修", "验收", "完成"];
  return labels.map((label, idx) => ({
    label,
    state: o.status === "CANCELLED" ? "pending" : idx + 1 < i ? "done" : idx + 1 === i ? "now" : "pending"
  }));
}
function shortWindow(w) {
  return String(w || "").split(/[（(]/)[0].trim();
}
function shortLeft(ms) {
  if (ms === null || ms === void 0) return "";
  if (ms <= 0) return "已超时";
  const m = Math.floor(ms / 6e4);
  const d = Math.floor(m / 1440);
  const h = Math.floor((m - d * 1440) / 60);
  const mm = m - d * 1440 - h * 60;
  if (d > 0) return `${d}d${h}h`;
  if (h > 0) return `${h}h${mm}m`;
  return `${mm}m`;
}
export {
  EVENT as E,
  STATUS as S,
  WALK_STATUS as W,
  steps as a,
  shortWindow as b,
  shortLeft as s
};
