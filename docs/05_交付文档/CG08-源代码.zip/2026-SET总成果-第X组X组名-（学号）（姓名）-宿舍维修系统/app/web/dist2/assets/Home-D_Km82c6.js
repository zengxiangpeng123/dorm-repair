import { f as ref, o as onMounted, h as onUnmounted, c as createElementBlock, a as createBaseVNode, t as toDisplayString, d as createCommentVNode, u as unref, i as createVNode, F as Fragment, r as renderList, j as computed, e as useRouter, g as openBlock } from "./index-CQHsh9DN.js";
import { B as BottomNav } from "./BottomNav-wi4vEY3F.js";
import { _ as _sfc_main$2 } from "./StatusPill-KCmlmcRf.js";
import { _ as _sfc_main$1 } from "./LevelPill-ZCCnoTlp.js";
import { _ as _export_sfc, a as actorOf, A as ACTORS, s as setActor, o as ordersApi } from "./_plugin-vue_export-helper-CJxN7Dmm.js";
import { s as shortLeft, a as steps } from "./status-BDo8bc0j.js";
const _hoisted_1 = { class: "top" };
const _hoisted_2 = { class: "between" };
const _hoisted_3 = { class: "tiny muted" };
const _hoisted_4 = { class: "name" };
const _hoisted_5 = { class: "body" };
const _hoisted_6 = {
  key: 0,
  class: "err"
};
const _hoisted_7 = { class: "card-hd" };
const _hoisted_8 = { class: "row" };
const _hoisted_9 = { class: "desc" };
const _hoisted_10 = { class: "steps" };
const _hoisted_11 = ["data-s"];
const _hoisted_12 = {
  key: 0,
  class: "timer"
};
const _hoisted_13 = {
  key: 2,
  class: "card empty"
};
const _hoisted_14 = {
  key: 3,
  class: "section-title"
};
const _hoisted_15 = ["data-st", "onClick"];
const _hoisted_16 = { class: "tx" };
const _hoisted_17 = { class: "r1" };
const _hoisted_18 = { class: "r2" };
const _hoisted_19 = { class: "r3" };
const _sfc_main = {
  __name: "Home",
  setup(__props) {
    const router = useRouter();
    const me = ref(actorOf("student"));
    const active = ref([]);
    const recent = ref([]);
    const loading = ref(true);
    const err = ref("");
    let timer = null;
    const current = computed(() => active.value[0] || null);
    const stepList = computed(() => current.value ? steps(current.value) : []);
    function leftOf(o) {
      const t = o.timers && (o.timers.t1 || o.timers.t2);
      return t ? shortLeft(t.leftMs) : "";
    }
    async function load() {
      try {
        const [a, all] = await Promise.all([ordersApi.myOrders("ACTIVE"), ordersApi.myOrders("ALL")]);
        active.value = a.items || [];
        recent.value = (all.items || []).slice(0, 4);
        err.value = "";
      } catch (e) {
        err.value = e.message || "加载失败";
      } finally {
        loading.value = false;
      }
    }
    function switchWho() {
      const list = ACTORS.student;
      const idx = list.findIndex((s) => s.id === me.value.id);
      const next = list[(idx + 1) % list.length];
      me.value = setActor("student", next.id);
      load();
    }
    onMounted(() => {
      load();
      timer = setInterval(load, 3e4);
    });
    onUnmounted(() => clearInterval(timer));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("header", _hoisted_1, [
          createBaseVNode("div", _hoisted_2, [
            createBaseVNode("div", null, [
              createBaseVNode("div", _hoisted_3, toDisplayString(me.value.building === "B7" ? "东区7号楼" : "东区8号楼") + " · " + toDisplayString(me.value.room) + " 室", 1),
              createBaseVNode("div", _hoisted_4, toDisplayString(me.value.name), 1)
            ]),
            createBaseVNode("button", {
              class: "switch",
              onClick: switchWho
            }, "换人")
          ])
        ]),
        createBaseVNode("div", _hoisted_5, [
          err.value ? (openBlock(), createElementBlock("p", _hoisted_6, toDisplayString(err.value), 1)) : createCommentVNode("", true),
          current.value ? (openBlock(), createElementBlock("div", {
            key: 1,
            class: "card cur",
            onClick: _cache[0] || (_cache[0] = ($event) => unref(router).push(`/student/detail/${current.value.no}`))
          }, [
            createBaseVNode("div", _hoisted_7, [
              createBaseVNode("h3", null, toDisplayString(current.value.building) + " " + toDisplayString(current.value.floor) + "F-" + toDisplayString(current.value.room), 1),
              createBaseVNode("div", _hoisted_8, [
                createVNode(_sfc_main$1, {
                  level: current.value.level
                }, null, 8, ["level"]),
                createVNode(_sfc_main$2, {
                  status: current.value.status
                }, null, 8, ["status"])
              ])
            ]),
            createBaseVNode("p", _hoisted_9, toDisplayString(current.value.desc), 1),
            createBaseVNode("div", _hoisted_10, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(stepList.value, (s, i) => {
                return openBlock(), createElementBlock("div", {
                  key: i,
                  class: "st",
                  "data-s": s.state
                }, [
                  _cache[2] || (_cache[2] = createBaseVNode("i", null, null, -1)),
                  createBaseVNode("span", null, toDisplayString(s.label), 1)
                ], 8, _hoisted_11);
              }), 128))
            ]),
            leftOf(current.value) ? (openBlock(), createElementBlock("div", _hoisted_12, [
              createBaseVNode("span", null, toDisplayString(current.value.timers.t1 ? "验收倒计时" : "归档倒计时"), 1),
              createBaseVNode("b", null, toDisplayString(leftOf(current.value)), 1)
            ])) : createCommentVNode("", true)
          ])) : !loading.value ? (openBlock(), createElementBlock("div", _hoisted_13, " 现在没有在办的报修。有东西坏了就报一单，师傅会自己看到。 ")) : createCommentVNode("", true),
          createBaseVNode("button", {
            class: "big-cta",
            onClick: _cache[1] || (_cache[1] = ($event) => unref(router).push("/student/new"))
          }, [..._cache[3] || (_cache[3] = [
            createBaseVNode("span", { class: "plus" }, "＋", -1),
            createBaseVNode("span", null, [
              createBaseVNode("b", null, "我要报修"),
              createBaseVNode("em", null, "拍一张、说一句，剩下的它自己跑")
            ], -1)
          ])]),
          recent.value.length ? (openBlock(), createElementBlock("div", _hoisted_14, "最近的报修")) : createCommentVNode("", true),
          (openBlock(true), createElementBlock(Fragment, null, renderList(recent.value, (o) => {
            return openBlock(), createElementBlock("div", {
              key: o.no,
              class: "ticket",
              "data-st": o.status,
              onClick: ($event) => unref(router).push(`/student/detail/${o.no}`)
            }, [
              createBaseVNode("div", _hoisted_16, [
                createBaseVNode("div", _hoisted_17, [
                  createBaseVNode("b", null, toDisplayString(o.building) + " " + toDisplayString(o.floor) + "F-" + toDisplayString(o.room), 1),
                  createVNode(_sfc_main$2, {
                    status: o.status
                  }, null, 8, ["status"])
                ]),
                createBaseVNode("div", _hoisted_18, toDisplayString(o.desc), 1),
                createBaseVNode("div", _hoisted_19, toDisplayString(o.no) + " · " + toDisplayString(o.category) + " · " + toDisplayString(o.level), 1)
              ])
            ], 8, _hoisted_15);
          }), 128))
        ]),
        createVNode(BottomNav, { role: "student" })
      ], 64);
    };
  }
};
const Home = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-abd2ac07"]]);
export {
  Home as default
};
