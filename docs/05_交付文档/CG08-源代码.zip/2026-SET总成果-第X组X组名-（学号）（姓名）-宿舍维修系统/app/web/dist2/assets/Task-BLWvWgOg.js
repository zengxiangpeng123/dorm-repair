import { o as onMounted, c as createElementBlock, a as createBaseVNode, u as unref, t as toDisplayString, d as createCommentVNode, i as createVNode, b as createTextVNode, F as Fragment, n as normalizeClass, r as renderList, k as withModifiers, w as withDirectives, v as vModelText, l as useRoute, e as useRouter, f as ref, j as computed, g as openBlock } from "./index-CQHsh9DN.js";
import { B as BottomNav } from "./BottomNav-wi4vEY3F.js";
import { _ as _sfc_main$2 } from "./Plate-3npaODG1.js";
import { _ as _sfc_main$1 } from "./StatusPill-KCmlmcRf.js";
import { _ as _sfc_main$3 } from "./LevelPill-ZCCnoTlp.js";
import { _ as _export_sfc, o as ordersApi, d as describeError } from "./_plugin-vue_export-helper-CJxN7Dmm.js";
import { b as shortWindow, E as EVENT } from "./status-BDo8bc0j.js";
const _hoisted_1 = { class: "top" };
const _hoisted_2 = { key: 0 };
const _hoisted_3 = {
  key: 1,
  class: "tiny muted"
};
const _hoisted_4 = {
  key: 0,
  class: "empty"
};
const _hoisted_5 = {
  key: 1,
  class: "empty"
};
const _hoisted_6 = {
  key: 2,
  class: "body has-dock"
};
const _hoisted_7 = { class: "card hero" };
const _hoisted_8 = { class: "hrow" };
const _hoisted_9 = { class: "htx" };
const _hoisted_10 = { class: "hno" };
const _hoisted_11 = { class: "tiny muted num" };
const _hoisted_12 = {
  class: "row",
  style: { "margin-top": "5px" }
};
const _hoisted_13 = { class: "pill plain" };
const _hoisted_14 = { class: "desc" };
const _hoisted_15 = { class: "kv" };
const _hoisted_16 = { class: "v" };
const _hoisted_17 = { class: "kv" };
const _hoisted_18 = { class: "v" };
const _hoisted_19 = {
  key: 0,
  class: "kv"
};
const _hoisted_20 = { class: "v tiny muted" };
const _hoisted_21 = {
  key: 0,
  class: "card"
};
const _hoisted_22 = { class: "btns" };
const _hoisted_23 = ["disabled"];
const _hoisted_24 = {
  key: 1,
  class: "card"
};
const _hoisted_25 = { class: "btns" };
const _hoisted_26 = {
  class: "note",
  "data-tone": "info",
  style: { "margin-top": "9px" }
};
const _hoisted_27 = {
  key: 2,
  class: "card"
};
const _hoisted_28 = { class: "card-hd" };
const _hoisted_29 = { class: "hint" };
const _hoisted_30 = { class: "money" };
const _hoisted_31 = { class: "n" };
const _hoisted_32 = { class: "n num" };
const _hoisted_33 = {
  key: 3,
  class: "card"
};
const _hoisted_34 = ["data-tone"];
const _hoisted_35 = { class: "card" };
const _hoisted_36 = { class: "card-hd" };
const _hoisted_37 = { class: "hint" };
const _hoisted_38 = { class: "thumbs" };
const _hoisted_39 = {
  key: 0,
  class: "thumb",
  "data-tone": "bad"
};
const _hoisted_40 = { class: "card" };
const _hoisted_41 = { class: "card-hd" };
const _hoisted_42 = { class: "hint" };
const _hoisted_43 = { class: "tl" };
const _hoisted_44 = ["data-s"];
const _hoisted_45 = { class: "t num" };
const _hoisted_46 = { class: "d" };
const _hoisted_47 = {
  key: 0,
  class: "tiny muted"
};
const _hoisted_48 = {
  key: 4,
  class: "err"
};
const _hoisted_49 = {
  key: 3,
  class: "dock"
};
const _hoisted_50 = { class: "sheet" };
const _hoisted_51 = { class: "sheet-hd" };
const _hoisted_52 = { style: { "margin-top": "4px" } };
const _hoisted_53 = {
  key: 0,
  class: "thumbs"
};
const _hoisted_54 = {
  class: "chips",
  style: { "margin-top": "6px" }
};
const _hoisted_55 = ["onClick"];
const _hoisted_56 = ["disabled"];
const _hoisted_57 = {
  key: 1,
  class: "err"
};
const _hoisted_58 = { class: "sheet" };
const _hoisted_59 = { class: "sheet-hd" };
const _hoisted_60 = ["data-tone"];
const _hoisted_61 = ["disabled"];
const _hoisted_62 = {
  key: 0,
  class: "err"
};
const _hoisted_63 = { class: "sheet" };
const _hoisted_64 = { class: "sheet-hd" };
const _hoisted_65 = { class: "chips" };
const _hoisted_66 = ["onClick"];
const _hoisted_67 = ["disabled"];
const _hoisted_68 = {
  key: 0,
  class: "err"
};
const _sfc_main = {
  __name: "Task",
  setup(__props) {
    const route = useRoute();
    const router = useRouter();
    const no = route.params.no;
    const o = ref(null);
    const meta = ref(null);
    const loading = ref(true);
    const err = ref("");
    const busy = ref("");
    const sheet = ref(null);
    const photoCount = ref(0);
    const noteTags = ref([]);
    const note = ref("");
    const parts = ref({ name: "", amount: "", eta: "" });
    const noShowReason = ref("");
    const canArrive = computed(() => {
      var _a, _b;
      return ((_a = o.value) == null ? void 0 : _a.status) === "ASSIGNED" && !((_b = o.value) == null ? void 0 : _b.arriveAt);
    });
    const canFinish = computed(() => {
      var _a;
      return ((_a = o.value) == null ? void 0 : _a.status) === "REPAIRING";
    });
    const budgetLine = computed(() => {
      var _a;
      return ((_a = meta.value) == null ? void 0 : _a.budgetLine) ?? 200;
    });
    const overBudget = computed(() => Number(parts.value.amount || 0) > budgetLine.value);
    const tags = computed(() => {
      var _a;
      return ((_a = meta.value) == null ? void 0 : _a.finishTags) || [];
    });
    const reasons = computed(() => {
      var _a;
      return ((_a = meta.value) == null ? void 0 : _a.noShowReasons) || [];
    });
    async function load() {
      var _a;
      try {
        const m = meta.value || await ordersApi.meta();
        meta.value = m;
        let target = no;
        if (!target) {
          const t = await ordersApi.workerTodo();
          const list = (t.buildings || []).flatMap((b) => b.orders || []);
          const rank = { REPAIRING: 0, ASSIGNED: 1, PARTS: 2, PENDING: 3 };
          list.sort((a, b) => (rank[a.status] ?? 9) - (rank[b.status] ?? 9));
          target = (_a = list[0]) == null ? void 0 : _a.no;
        }
        if (!target) {
          err.value = "本楼暂时没有要处理的单";
          return;
        }
        o.value = await ordersApi.detail(target);
        parts.value.eta = tomorrow();
      } catch (e) {
        err.value = describeError(e);
      } finally {
        loading.value = false;
      }
    }
    function tomorrow() {
      const d = new Date(Date.now() + 864e5);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    }
    async function fire(path, body, tag) {
      busy.value = tag;
      err.value = "";
      try {
        await path(o.value.no, { ...body, version: o.value.version });
        sheet.value = null;
        await load();
      } catch (e) {
        err.value = describeError(e);
        if (e.status === 409) load();
      } finally {
        busy.value = "";
      }
    }
    function openSheet(k) {
      var _a;
      if (k === "finish") {
        photoCount.value = 0;
        noteTags.value = [];
        note.value = "";
      }
      if (k === "parts") {
        parts.value = { name: "", amount: "", eta: tomorrow() };
      }
      if (k === "noshow") noShowReason.value = ((_a = reasons.value[0]) == null ? void 0 : _a.code) || "";
      sheet.value = k;
    }
    function submitFinish() {
      if (!photoCount.value) return;
      const photos = Array.from({ length: photoCount.value }, (_, i) => `demo://after/${o.value.no}-${i + 1}.jpg`);
      const text = [...noteTags.value, note.value.trim()].filter(Boolean).join("、") || "完工提交";
      fire(ordersApi.finish, { photosAfter: photos, note: text }, "finish");
    }
    function submitParts() {
      if (!parts.value.name.trim() || !(Number(parts.value.amount) > 0)) return;
      fire(ordersApi.needParts, {
        partsName: parts.value.name.trim(),
        partsAmount: Number(parts.value.amount),
        partsEta: parts.value.eta,
        note: `缺件：${parts.value.name.trim()}`
      }, "parts");
    }
    onMounted(load);
    return (_ctx, _cache) => {
      var _a;
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("header", _hoisted_1, [
          createBaseVNode("button", {
            class: "back",
            onClick: _cache[0] || (_cache[0] = ($event) => unref(router).push("/worker"))
          }, "‹ 工作台"),
          o.value ? (openBlock(), createElementBlock("b", _hoisted_2, toDisplayString(o.value.floor) + "F-" + toDisplayString(o.value.room), 1)) : createCommentVNode("", true),
          o.value ? (openBlock(), createElementBlock("span", _hoisted_3, [
            createVNode(_sfc_main$1, {
              status: o.value.status
            }, null, 8, ["status"])
          ])) : createCommentVNode("", true)
        ]),
        loading.value ? (openBlock(), createElementBlock("div", _hoisted_4, "加载中…")) : !o.value ? (openBlock(), createElementBlock("div", _hoisted_5, toDisplayString(err.value || "没有要处理的单"), 1)) : (openBlock(), createElementBlock("div", _hoisted_6, [
          createBaseVNode("div", _hoisted_7, [
            createBaseVNode("div", _hoisted_8, [
              createVNode(_sfc_main$2, {
                room: o.value.room,
                floor: o.value.floor,
                status: o.value.status,
                large: ""
              }, null, 8, ["room", "floor", "status"]),
              createBaseVNode("div", _hoisted_9, [
                createBaseVNode("div", _hoisted_10, toDisplayString(o.value.building) + " " + toDisplayString(o.value.floor) + "F-" + toDisplayString(o.value.room), 1),
                createBaseVNode("div", _hoisted_11, [
                  createTextVNode(toDisplayString(o.value.no), 1),
                  o.value.reworkOf ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                    createTextVNode(" · 返修 R" + toDisplayString(o.value.reworkIndex), 1)
                  ], 64)) : createCommentVNode("", true)
                ]),
                createBaseVNode("div", _hoisted_12, [
                  createVNode(_sfc_main$3, {
                    level: o.value.level
                  }, null, 8, ["level"]),
                  createBaseVNode("span", _hoisted_13, toDisplayString(o.value.category), 1)
                ])
              ])
            ]),
            createBaseVNode("p", _hoisted_14, toDisplayString(o.value.desc), 1),
            createBaseVNode("div", _hoisted_15, [
              _cache[20] || (_cache[20] = createBaseVNode("span", { class: "k" }, "学生", -1)),
              createBaseVNode("span", _hoisted_16, toDisplayString(o.value.studentName), 1)
            ]),
            createBaseVNode("div", _hoisted_17, [
              _cache[21] || (_cache[21] = createBaseVNode("span", { class: "k" }, "可上门", -1)),
              createBaseVNode("span", _hoisted_18, toDisplayString(unref(shortWindow)(o.value.window) || "全天"), 1)
            ]),
            o.value.aiBasis ? (openBlock(), createElementBlock("div", _hoisted_19, [
              _cache[22] || (_cache[22] = createBaseVNode("span", { class: "k" }, "系统判的", -1)),
              createBaseVNode("span", _hoisted_20, toDisplayString(o.value.aiBasis), 1)
            ])) : createCommentVNode("", true)
          ]),
          canArrive.value ? (openBlock(), createElementBlock("div", _hoisted_21, [
            _cache[23] || (_cache[23] = createBaseVNode("div", { class: "card-hd" }, [
              createBaseVNode("h3", null, "① 能进场吗"),
              createBaseVNode("span", { class: "hint" }, "必须本人打卡")
            ], -1)),
            createBaseVNode("div", _hoisted_22, [
              createBaseVNode("button", {
                class: "dbtn primary",
                disabled: busy.value === "arrive",
                onClick: _cache[1] || (_cache[1] = ($event) => fire(unref(ordersApi).arrive, { note: "到门打卡" }, "arrive"))
              }, toDisplayString(busy.value === "arrive" ? "打卡中…" : "门开着，进楼修"), 9, _hoisted_23),
              createBaseVNode("button", {
                class: "dbtn",
                onClick: _cache[2] || (_cache[2] = ($event) => openSheet("noshow"))
              }, "敲了没人应")
            ]),
            _cache[24] || (_cache[24] = createBaseVNode("div", {
              class: "note",
              style: { "margin-top": "9px" }
            }, " 在楼门口打卡会把这一批单一起记「到门」。人没见到就选「敲了没人应」，这单回队列重排，不算你白跑。 ", -1))
          ])) : canFinish.value ? (openBlock(), createElementBlock("div", _hoisted_24, [
            _cache[25] || (_cache[25] = createBaseVNode("div", { class: "card-hd" }, [
              createBaseVNode("h3", null, "② 能当场修好吗")
            ], -1)),
            createBaseVNode("div", _hoisted_25, [
              createBaseVNode("button", {
                class: "dbtn primary",
                onClick: _cache[3] || (_cache[3] = ($event) => openSheet("finish"))
              }, "修好了，上传完工照"),
              createBaseVNode("button", {
                class: "dbtn",
                onClick: _cache[4] || (_cache[4] = ($event) => openSheet("parts"))
              }, "缺配件，先登记")
            ]),
            createBaseVNode("div", _hoisted_26, " 登记缺件要填名称和金额。金额超过 " + toDisplayString(budgetLine.value) + " 元会进管理端审批，配件到了这单自动回队列。 ", 1)
          ])) : o.value.status === "PARTS" ? (openBlock(), createElementBlock("div", _hoisted_27, [
            createBaseVNode("div", _hoisted_28, [
              _cache[26] || (_cache[26] = createBaseVNode("h3", null, "等配件", -1)),
              createBaseVNode("span", _hoisted_29, toDisplayString(o.value.partsEta || ""), 1)
            ]),
            createBaseVNode("div", _hoisted_30, [
              createBaseVNode("div", null, [
                createBaseVNode("div", _hoisted_31, toDisplayString(o.value.partsName), 1),
                _cache[27] || (_cache[27] = createBaseVNode("div", { class: "k" }, "配件", -1))
              ]),
              createBaseVNode("div", null, [
                createBaseVNode("div", {
                  class: normalizeClass(["n num", { hot: Number(o.value.partsAmount) > budgetLine.value }])
                }, "¥" + toDisplayString(o.value.partsAmount), 3),
                _cache[28] || (_cache[28] = createBaseVNode("div", { class: "k" }, "金额", -1))
              ]),
              createBaseVNode("div", null, [
                createBaseVNode("div", _hoisted_32, "¥" + toDisplayString(budgetLine.value), 1),
                _cache[29] || (_cache[29] = createBaseVNode("div", { class: "k" }, "预算线", -1))
              ])
            ]),
            _cache[30] || (_cache[30] = createBaseVNode("div", {
              class: "note",
              style: { "margin-top": "9px" }
            }, "配件到货后系统把这单放回队列，定级不降。你可以在「等配件」里确认到货。", -1))
          ])) : (openBlock(), createElementBlock("div", _hoisted_33, [
            createBaseVNode("div", {
              class: "note",
              "data-tone": o.value.status === "VERIFYING" ? "info" : ""
            }, toDisplayString(o.value.status === "VERIFYING" ? "已经完工，等学生验收。验收通过或超时自动验收后这单结束。" : `这单现在是「${o.value.statusLabel}」，不需要你动手。`), 9, _hoisted_34)
          ])),
          createBaseVNode("div", _hoisted_35, [
            createBaseVNode("div", _hoisted_36, [
              _cache[31] || (_cache[31] = createBaseVNode("h3", null, "照片", -1)),
              createBaseVNode("span", _hoisted_37, "学生 " + toDisplayString((o.value.photosBefore || []).length) + " 张 · 你上传 " + toDisplayString((o.value.photosAfter || []).length) + " 张", 1)
            ]),
            createBaseVNode("div", _hoisted_38, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(o.value.photosBefore, (p, i) => {
                return openBlock(), createElementBlock("div", {
                  key: p,
                  class: "thumb"
                }, [
                  _cache[32] || (_cache[32] = createBaseVNode("span", null, "📷", -1)),
                  createBaseVNode("span", null, "现场 " + toDisplayString(i + 1), 1)
                ]);
              }), 128)),
              (openBlock(true), createElementBlock(Fragment, null, renderList(o.value.photosAfter, (p, i) => {
                return openBlock(), createElementBlock("div", {
                  key: p,
                  class: "thumb",
                  "data-tone": "ok"
                }, [
                  _cache[33] || (_cache[33] = createBaseVNode("span", null, "📸", -1)),
                  createBaseVNode("span", null, "完工 " + toDisplayString(i + 1), 1)
                ]);
              }), 128)),
              !((_a = o.value.photosAfter) == null ? void 0 : _a.length) ? (openBlock(), createElementBlock("div", _hoisted_39, [..._cache[34] || (_cache[34] = [
                createBaseVNode("span", null, "⚠️", -1),
                createBaseVNode("span", null, "完工照必填", -1)
              ])])) : createCommentVNode("", true)
            ])
          ]),
          createBaseVNode("div", _hoisted_40, [
            createBaseVNode("div", _hoisted_41, [
              _cache[35] || (_cache[35] = createBaseVNode("h3", null, "这单经过", -1)),
              createBaseVNode("span", _hoisted_42, "最近 " + toDisplayString(Math.min(6, (o.value.events || []).length)) + " 步", 1)
            ]),
            createBaseVNode("div", _hoisted_43, [
              (openBlock(true), createElementBlock(Fragment, null, renderList((o.value.events || []).slice(-6), (e, i) => {
                return openBlock(), createElementBlock("div", {
                  key: e.seq || i,
                  class: "ev",
                  "data-s": i === (o.value.events || []).slice(-6).length - 1 ? "now" : "done"
                }, [
                  createBaseVNode("div", _hoisted_45, toDisplayString(String(e.at).slice(5, 16)), 1),
                  createBaseVNode("div", _hoisted_46, [
                    createTextVNode(toDisplayString(unref(EVENT)[e.event] || e.event), 1),
                    e.manual === 0 ? (openBlock(), createElementBlock("span", _hoisted_47, " · 系统自动")) : createCommentVNode("", true)
                  ])
                ], 8, _hoisted_44);
              }), 128))
            ])
          ]),
          err.value ? (openBlock(), createElementBlock("p", _hoisted_48, toDisplayString(err.value), 1)) : createCommentVNode("", true)
        ])),
        o.value ? (openBlock(), createElementBlock("div", _hoisted_49, [
          canArrive.value ? (openBlock(), createElementBlock("button", {
            key: 0,
            class: "dbtn primary",
            onClick: _cache[5] || (_cache[5] = ($event) => openSheet("noshow"))
          }, "人没见到")) : canFinish.value ? (openBlock(), createElementBlock("button", {
            key: 1,
            class: "dbtn primary",
            onClick: _cache[6] || (_cache[6] = ($event) => openSheet("finish"))
          }, "完工")) : (openBlock(), createElementBlock("button", {
            key: 2,
            class: "dbtn",
            onClick: _cache[7] || (_cache[7] = ($event) => unref(router).push("/worker"))
          }, "回工作台"))
        ])) : createCommentVNode("", true),
        sheet.value === "finish" ? (openBlock(), createElementBlock("div", {
          key: 4,
          class: "mask",
          onClick: _cache[11] || (_cache[11] = withModifiers(($event) => sheet.value = null, ["self"]))
        }, [
          createBaseVNode("div", _hoisted_50, [
            createBaseVNode("div", _hoisted_51, [
              _cache[36] || (_cache[36] = createBaseVNode("b", null, "完工提交", -1)),
              createBaseVNode("button", {
                onClick: _cache[8] || (_cache[8] = ($event) => sheet.value = null)
              }, "取消")
            ]),
            createBaseVNode("button", {
              class: "uploader",
              onClick: _cache[9] || (_cache[9] = ($event) => photoCount.value = Math.min(3, photoCount.value + 1))
            }, [
              _cache[37] || (_cache[37] = createBaseVNode("div", { style: { "font-size": "20px" } }, "📸", -1)),
              createBaseVNode("div", _hoisted_52, "拍完工照（必填，已拍 " + toDisplayString(photoCount.value) + " 张）", 1)
            ]),
            photoCount.value ? (openBlock(), createElementBlock("div", _hoisted_53, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(photoCount.value, (i) => {
                return openBlock(), createElementBlock("div", {
                  key: i,
                  class: "thumb",
                  "data-tone": "ok"
                }, [
                  _cache[38] || (_cache[38] = createBaseVNode("span", null, "📸", -1)),
                  createBaseVNode("span", null, "第 " + toDisplayString(i) + " 张", 1)
                ]);
              }), 128))
            ])) : createCommentVNode("", true),
            _cache[39] || (_cache[39] = createBaseVNode("div", {
              class: "lb",
              style: { "margin-top": "12px" }
            }, "动了什么（可多选）", -1)),
            createBaseVNode("div", _hoisted_54, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(tags.value, (t) => {
                return openBlock(), createElementBlock("button", {
                  key: t,
                  class: normalizeClass(["chip", { on: noteTags.value.includes(t) }]),
                  onClick: ($event) => noteTags.value.includes(t) ? noteTags.value.splice(noteTags.value.indexOf(t), 1) : noteTags.value.push(t)
                }, toDisplayString(t), 11, _hoisted_55);
              }), 128))
            ]),
            _cache[40] || (_cache[40] = createBaseVNode("div", {
              class: "lb",
              style: { "margin-top": "12px" }
            }, "补充一句（可不写）", -1)),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[10] || (_cache[10] = ($event) => note.value = $event),
              class: "in",
              placeholder: "举个例子：阀芯老化，换完不漏了"
            }, null, 512), [
              [vModelText, note.value]
            ]),
            createBaseVNode("button", {
              class: "submit",
              disabled: !photoCount.value || !!busy.value,
              onClick: submitFinish
            }, toDisplayString(busy.value === "finish" ? "提交中…" : "提交完工"), 9, _hoisted_56),
            err.value ? (openBlock(), createElementBlock("p", _hoisted_57, toDisplayString(err.value), 1)) : createCommentVNode("", true)
          ])
        ])) : createCommentVNode("", true),
        sheet.value === "parts" ? (openBlock(), createElementBlock("div", {
          key: 5,
          class: "mask",
          onClick: _cache[16] || (_cache[16] = withModifiers(($event) => sheet.value = null, ["self"]))
        }, [
          createBaseVNode("div", _hoisted_58, [
            createBaseVNode("div", _hoisted_59, [
              _cache[41] || (_cache[41] = createBaseVNode("b", null, "缺什么配件", -1)),
              createBaseVNode("button", {
                onClick: _cache[12] || (_cache[12] = ($event) => sheet.value = null)
              }, "取消")
            ]),
            _cache[42] || (_cache[42] = createBaseVNode("div", { class: "lb" }, "配件名称", -1)),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[13] || (_cache[13] = ($event) => parts.value.name = $event),
              class: "in",
              placeholder: "举个例子：角阀"
            }, null, 512), [
              [vModelText, parts.value.name]
            ]),
            _cache[43] || (_cache[43] = createBaseVNode("div", {
              class: "lb",
              style: { "margin-top": "10px" }
            }, "多少钱", -1)),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[14] || (_cache[14] = ($event) => parts.value.amount = $event),
              class: "in num",
              inputmode: "decimal",
              placeholder: "38"
            }, null, 512), [
              [vModelText, parts.value.amount]
            ]),
            _cache[44] || (_cache[44] = createBaseVNode("div", {
              class: "lb",
              style: { "margin-top": "10px" }
            }, "预计哪天到货", -1)),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[15] || (_cache[15] = ($event) => parts.value.eta = $event),
              type: "date",
              class: "in num"
            }, null, 512), [
              [vModelText, parts.value.eta]
            ]),
            createBaseVNode("div", {
              class: "note",
              "data-tone": overBudget.value ? "warn" : "info",
              style: { "margin-top": "10px" }
            }, toDisplayString(overBudget.value ? `超过预算线 ${budgetLine.value} 元，这笔会进管理端「超预算采购」清单等审批，别自己先垫钱买。` : `在 ${budgetLine.value} 元预算线内，登记完直接进采购。`), 9, _hoisted_60),
            createBaseVNode("button", {
              class: "submit",
              disabled: !parts.value.name.trim() || !(Number(parts.value.amount) > 0) || !!busy.value,
              onClick: submitParts
            }, toDisplayString(busy.value === "parts" ? "提交中…" : "登记缺件"), 9, _hoisted_61),
            err.value ? (openBlock(), createElementBlock("p", _hoisted_62, toDisplayString(err.value), 1)) : createCommentVNode("", true)
          ])
        ])) : createCommentVNode("", true),
        sheet.value === "noshow" ? (openBlock(), createElementBlock("div", {
          key: 6,
          class: "mask",
          onClick: _cache[19] || (_cache[19] = withModifiers(($event) => sheet.value = null, ["self"]))
        }, [
          createBaseVNode("div", _hoisted_63, [
            createBaseVNode("div", _hoisted_64, [
              _cache[45] || (_cache[45] = createBaseVNode("b", null, "人没见到", -1)),
              createBaseVNode("button", {
                onClick: _cache[17] || (_cache[17] = ($event) => sheet.value = null)
              }, "取消")
            ]),
            createBaseVNode("div", _hoisted_65, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(reasons.value, (r) => {
                return openBlock(), createElementBlock("button", {
                  key: r.code,
                  class: normalizeClass(["chip", { on: noShowReason.value === r.code }]),
                  onClick: ($event) => noShowReason.value = r.code
                }, toDisplayString(r.label), 11, _hoisted_66);
              }), 128))
            ]),
            _cache[46] || (_cache[46] = createBaseVNode("p", {
              class: "note",
              "data-tone": "warn",
              style: { "margin-top": "10px" }
            }, " 这张单会回队列重排，系统记一笔「到访未遇」。这不是白跑——有记录，就不是你说了算也不是学生说了算。 ", -1)),
            createBaseVNode("button", {
              class: "submit",
              disabled: !noShowReason.value || !!busy.value,
              onClick: _cache[18] || (_cache[18] = ($event) => fire(unref(ordersApi).noShow, { reason: noShowReason.value }, "noshow"))
            }, toDisplayString(busy.value === "noshow" ? "提交中…" : "确认人没见到"), 9, _hoisted_67),
            err.value ? (openBlock(), createElementBlock("p", _hoisted_68, toDisplayString(err.value), 1)) : createCommentVNode("", true)
          ])
        ])) : createCommentVNode("", true),
        createVNode(BottomNav, { role: "worker" })
      ], 64);
    };
  }
};
const Task = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-a382eea9"]]);
export {
  Task as default
};
