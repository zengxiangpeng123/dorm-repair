import { o as onMounted, c as createElementBlock, a as createBaseVNode, t as toDisplayString, u as unref, d as createCommentVNode, i as createVNode, b as createTextVNode, F as Fragment, r as renderList, j as computed, f as ref, e as useRouter, g as openBlock } from "./index-CQHsh9DN.js";
import { B as BottomNav } from "./BottomNav-wi4vEY3F.js";
import { _ as _sfc_main$2 } from "./Plate-3npaODG1.js";
import { _ as _sfc_main$1 } from "./StatusPill-KCmlmcRf.js";
import { _ as _export_sfc, a as actorOf, o as ordersApi, d as describeError } from "./_plugin-vue_export-helper-CJxN7Dmm.js";
import { b as shortWindow, s as shortLeft } from "./status-BDo8bc0j.js";
import { a as timersOf } from "./timers-CbMtjaoE.js";
const _hoisted_1 = { class: "worktop" };
const _hoisted_2 = { class: "who" };
const _hoisted_3 = { class: "name" };
const _hoisted_4 = { class: "team" };
const _hoisted_5 = { class: "badge" };
const _hoisted_6 = { class: "tally" };
const _hoisted_7 = { class: "n num" };
const _hoisted_8 = { class: "n num" };
const _hoisted_9 = { class: "n num" };
const _hoisted_10 = { class: "n num" };
const _hoisted_11 = { class: "body has-dock" };
const _hoisted_12 = {
  key: 0,
  class: "err"
};
const _hoisted_13 = {
  key: 1,
  class: "card next"
};
const _hoisted_14 = { class: "between" };
const _hoisted_15 = { class: "nx" };
const _hoisted_16 = { class: "nx-tx" };
const _hoisted_17 = { class: "nx-r" };
const _hoisted_18 = { class: "nx-d" };
const _hoisted_19 = { class: "nx-m" };
const _hoisted_20 = {
  key: 2,
  class: "card empty"
};
const _hoisted_21 = {
  key: 3,
  class: "section-title"
};
const _hoisted_22 = ["data-st", "onClick"];
const _hoisted_23 = { class: "tx" };
const _hoisted_24 = { class: "r1" };
const _hoisted_25 = { class: "r2" };
const _hoisted_26 = { class: "r3" };
const _hoisted_27 = {
  key: 0,
  class: "tiny",
  style: { "color": "var(--orange)", "margin-top": "3px" }
};
const _hoisted_28 = { class: "dock" };
const _hoisted_29 = ["disabled"];
const _hoisted_30 = {
  key: 0,
  class: "toast"
};
const _sfc_main = {
  __name: "Home",
  setup(__props) {
    const router = useRouter();
    const me = actorOf("worker");
    const todo = ref(null);
    const meta = ref(null);
    const loading = ref(true);
    const err = ref("");
    const busy = ref(false);
    const ORDER = { REPAIRING: 0, ASSIGNED: 1, PARTS: 2, PENDING: 3 };
    const hasCancelRequest = (o) => (o.events || []).some((e) => e.event === "CANCEL_REQUEST");
    const buildings = computed(() => {
      var _a;
      return ((_a = todo.value) == null ? void 0 : _a.buildings) || [];
    });
    const summary = computed(() => {
      var _a;
      return ((_a = todo.value) == null ? void 0 : _a.summary) || { todo: 0, repairing: 0, parts: 0 };
    });
    const main = computed(() => buildings.value[0] || null);
    const arrived = computed(() => {
      var _a;
      return !!((_a = main.value) == null ? void 0 : _a.arrived) && main.value.orders.some((o) => o.arriveAt);
    });
    const queue = computed(() => {
      var _a;
      const list = [...((_a = main.value) == null ? void 0 : _a.orders) || []];
      return list.sort((a, b) => (ORDER[a.status] ?? 9) - (ORDER[b.status] ?? 9) || b.floor - a.floor);
    });
    const next = computed(() => queue.value[0] || null);
    const doneCount = computed(() => {
      var _a, _b;
      return ((_b = (_a = main.value) == null ? void 0 : _a.progress) == null ? void 0 : _b.done) ?? 0;
    });
    const stayed = computed(() => {
      if (!next.value) return "";
      const t = timersOf(next.value, meta.value);
      return t.stayedMs ? shortLeft(t.stayedMs) : "";
    });
    async function load() {
      try {
        const [t, m] = await Promise.all([ordersApi.workerTodo(), ordersApi.meta()]);
        todo.value = t;
        meta.value = m;
        err.value = "";
      } catch (e) {
        err.value = describeError(e);
      } finally {
        loading.value = false;
      }
    }
    async function arriveBatch() {
      if (!main.value) return;
      busy.value = true;
      err.value = "";
      try {
        const r = await ordersApi.arriveBuilding(main.value.buildingId, {}, { role: "worker" });
        const ok = (r.ok || []).length;
        const skipped = (r.skipped || []).length;
        await load();
        alertSkip(ok, skipped);
      } catch (e) {
        err.value = describeError(e);
      } finally {
        busy.value = false;
      }
    }
    function alertSkip(ok, skipped) {
      window.setTimeout(() => {
      }, 0);
      toast.value = `已打卡 ${ok} 单${skipped ? `，${skipped} 单已在楼内跳过` : ""}`;
      window.clearTimeout(toastTimer);
      toastTimer = window.setTimeout(() => {
        toast.value = "";
      }, 2600);
    }
    const toast = ref("");
    let toastTimer = null;
    onMounted(load);
    return (_ctx, _cache) => {
      var _a;
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("header", _hoisted_1, [
          createBaseVNode("div", _hoisted_2, [
            createBaseVNode("div", null, [
              createBaseVNode("div", _hoisted_3, toDisplayString(unref(me).name), 1),
              createBaseVNode("div", _hoisted_4, toDisplayString(unref(me).team) + " · 负责" + toDisplayString(unref(me).building === "B7" ? "东区7号楼" : "东区8号楼"), 1)
            ]),
            createBaseVNode("div", _hoisted_5, toDisplayString(arrived.value ? "已在楼内" : "还没进楼"), 1)
          ]),
          createBaseVNode("div", _hoisted_6, [
            createBaseVNode("div", null, [
              createBaseVNode("div", _hoisted_7, toDisplayString(summary.value.todo), 1),
              _cache[2] || (_cache[2] = createBaseVNode("div", { class: "k" }, "待我上门", -1))
            ]),
            createBaseVNode("div", null, [
              createBaseVNode("div", _hoisted_8, toDisplayString(summary.value.repairing), 1),
              _cache[3] || (_cache[3] = createBaseVNode("div", { class: "k" }, "正在修", -1))
            ]),
            createBaseVNode("div", null, [
              createBaseVNode("div", _hoisted_9, toDisplayString(summary.value.parts), 1),
              _cache[4] || (_cache[4] = createBaseVNode("div", { class: "k" }, "等配件", -1))
            ]),
            createBaseVNode("div", null, [
              createBaseVNode("div", _hoisted_10, toDisplayString(doneCount.value), 1),
              _cache[5] || (_cache[5] = createBaseVNode("div", { class: "k" }, "本楼已完", -1))
            ])
          ])
        ]),
        createBaseVNode("div", _hoisted_11, [
          err.value ? (openBlock(), createElementBlock("p", _hoisted_12, toDisplayString(err.value), 1)) : createCommentVNode("", true),
          next.value ? (openBlock(), createElementBlock("div", _hoisted_13, [
            createBaseVNode("div", _hoisted_14, [
              _cache[6] || (_cache[6] = createBaseVNode("span", { class: "tiny muted" }, "下一间", -1)),
              createVNode(_sfc_main$1, {
                status: next.value.status
              }, null, 8, ["status"])
            ]),
            createBaseVNode("div", _hoisted_15, [
              createVNode(_sfc_main$2, {
                room: next.value.room,
                floor: next.value.floor,
                status: next.value.status,
                large: ""
              }, null, 8, ["room", "floor", "status"]),
              createBaseVNode("div", _hoisted_16, [
                createBaseVNode("div", _hoisted_17, toDisplayString(next.value.building) + " " + toDisplayString(next.value.floor) + "F-" + toDisplayString(next.value.room), 1),
                createBaseVNode("div", _hoisted_18, toDisplayString(next.value.desc), 1),
                createBaseVNode("div", _hoisted_19, [
                  createTextVNode(toDisplayString(next.value.studentName) + " · " + toDisplayString(unref(shortWindow)(next.value.window) || "全天") + " ", 1),
                  stayed.value ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                    createTextVNode(" · 已停留 " + toDisplayString(stayed.value), 1)
                  ], 64)) : createCommentVNode("", true)
                ])
              ])
            ]),
            createBaseVNode("button", {
              class: "go",
              onClick: _cache[0] || (_cache[0] = ($event) => unref(router).push(`/worker/task/${next.value.no}`))
            }, toDisplayString(next.value.status === "REPAIRING" ? "进去接着修" : next.value.status === "ASSIGNED" ? "到门打卡" : "打开这单"), 1)
          ])) : !loading.value ? (openBlock(), createElementBlock("div", _hoisted_20, " 本楼没有要上楼的活。等学生报修，系统会自己派过来。 ")) : createCommentVNode("", true),
          queue.value.length > 1 ? (openBlock(), createElementBlock("div", _hoisted_21, "本楼还有 " + toDisplayString(queue.value.length - 1) + " 单", 1)) : createCommentVNode("", true),
          (openBlock(true), createElementBlock(Fragment, null, renderList(queue.value.slice(1), (o) => {
            return openBlock(), createElementBlock("div", {
              key: o.no,
              class: "ticket",
              "data-st": o.status,
              onClick: ($event) => unref(router).push(`/worker/task/${o.no}`)
            }, [
              createVNode(_sfc_main$2, {
                room: o.room,
                floor: o.floor,
                status: o.status
              }, null, 8, ["room", "floor", "status"]),
              createBaseVNode("div", _hoisted_23, [
                createBaseVNode("div", _hoisted_24, [
                  createBaseVNode("b", null, toDisplayString(o.floor) + "F-" + toDisplayString(o.room), 1),
                  createVNode(_sfc_main$1, {
                    status: o.status
                  }, null, 8, ["status"])
                ]),
                createBaseVNode("div", _hoisted_25, toDisplayString(o.desc), 1),
                createBaseVNode("div", _hoisted_26, toDisplayString(o.category) + " · " + toDisplayString(o.level) + " · " + toDisplayString(unref(shortWindow)(o.window) || "全天"), 1),
                hasCancelRequest(o) ? (openBlock(), createElementBlock("div", _hoisted_27, "学生申请撤销，等管理员定")) : createCommentVNode("", true)
              ])
            ], 8, _hoisted_22);
          }), 128))
        ]),
        createBaseVNode("div", _hoisted_28, [
          !arrived.value ? (openBlock(), createElementBlock("button", {
            key: 0,
            class: "dbtn primary",
            disabled: busy.value,
            onClick: arriveBatch
          }, toDisplayString(busy.value ? "打卡中…" : `进楼打卡 · ${((_a = main.value) == null ? void 0 : _a.buildingName) || "本楼"}`), 9, _hoisted_29)) : (openBlock(), createElementBlock("button", {
            key: 1,
            class: "dbtn",
            onClick: _cache[1] || (_cache[1] = ($event) => unref(router).push("/worker/building"))
          }, "看本楼清单"))
        ]),
        _cache[7] || (_cache[7] = createBaseVNode("div", {
          class: "tip",
          "data-tone": "info"
        }, ' 进楼打卡一次，本批的单一起记「到门」。学生看到的就是"师傅已进楼"。 ', -1)),
        toast.value ? (openBlock(), createElementBlock("div", _hoisted_30, toDisplayString(toast.value), 1)) : createCommentVNode("", true),
        createVNode(BottomNav, { role: "worker" })
      ], 64);
    };
  }
};
const Home = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-eb66ff42"]]);
export {
  Home as default
};
