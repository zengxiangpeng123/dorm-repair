import { l as useRoute, e as useRouter, g as openBlock, c as createElementBlock, F as Fragment, r as renderList, k as withModifiers, n as normalizeClass, u as unref, a as createBaseVNode, t as toDisplayString, j as computed } from "./index-CQHsh9DN.js";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-CJxN7Dmm.js";
const _hoisted_1 = { class: "bottom-nav" };
const _hoisted_2 = ["onClick"];
const _hoisted_3 = {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  "stroke-width": "1.8",
  "stroke-linecap": "round",
  "stroke-linejoin": "round"
};
const _hoisted_4 = ["d"];
const _sfc_main = {
  __name: "BottomNav",
  props: { role: { type: String, default: "student" } },
  setup(__props) {
    const props = __props;
    const route = useRoute();
    const router = useRouter();
    const ICONS = {
      home: "M3 10.5 12 3l9 7.5V21H3z",
      list: "M4 6h16M4 12h16M4 18h10",
      plus: "M12 5v14M5 12h14",
      wrench: "M14 7a4 4 0 1 0 5 5L9 22l-3-3 10-10z",
      stairs: "M4 19h5v-4h5v-4h5V7",
      box: "M4 8h16v12H4zM4 8l8-4 8 4",
      monitor: "M3 5h18v11H3zM8 20h8",
      info: "M12 8h.01M11 12h1v5h1"
    };
    const items = computed(() => {
      if (props.role === "worker") {
        return [
          { to: "/worker", label: "工作台", icon: "home", match: (p) => p === "/worker" },
          { to: "/worker/building", label: "本楼", icon: "stairs", match: (p) => p.startsWith("/worker/building") },
          { to: "/worker/task", label: "开工", icon: "wrench", match: (p) => p.startsWith("/worker/task") },
          { to: "/worker/parts", label: "等配件", icon: "box", match: (p) => p.startsWith("/worker/parts") }
        ];
      }
      return [
        { to: "/student", label: "首页", icon: "home", match: (p) => p === "/student" },
        { to: "/student/list", label: "我的报修", icon: "list", match: (p) => p.startsWith("/student/list") || p.startsWith("/student/detail") },
        { to: "/student/new", label: "报修", icon: "plus", match: (p) => p.startsWith("/student/new"), cta: true },
        { to: "/lab", label: "说明", icon: "info", match: () => false }
      ];
    });
    function go(to) {
      router.push(to);
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("nav", _hoisted_1, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(items.value, (it) => {
          return openBlock(), createElementBlock("a", {
            key: it.to,
            href: "#",
            class: normalizeClass({ on: it.match(unref(route).path), cta: it.cta }),
            onClick: withModifiers(($event) => go(it.to), ["prevent"])
          }, [
            (openBlock(), createElementBlock("svg", _hoisted_3, [
              createBaseVNode("path", {
                d: ICONS[it.icon]
              }, null, 8, _hoisted_4)
            ])),
            createBaseVNode("span", null, toDisplayString(it.label), 1)
          ], 10, _hoisted_2);
        }), 128))
      ]);
    };
  }
};
const BottomNav = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-ea6bd84e"]]);
export {
  BottomNav as B
};
