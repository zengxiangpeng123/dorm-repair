import { g as openBlock, c as createElementBlock, a as createBaseVNode, t as toDisplayString, d as createCommentVNode, n as normalizeClass } from "./index-CQHsh9DN.js";
const _hoisted_1 = ["data-st"];
const _hoisted_2 = { class: "r num" };
const _hoisted_3 = {
  key: 0,
  class: "f"
};
const _sfc_main = {
  __name: "Plate",
  props: {
    room: { type: String, required: true },
    floor: { type: [Number, String], default: "" },
    status: { type: String, default: "PENDING" },
    large: Boolean
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["plate", { lg: __props.large }]),
        "data-st": __props.status
      }, [
        createBaseVNode("span", _hoisted_2, toDisplayString(__props.room), 1),
        __props.floor ? (openBlock(), createElementBlock("span", _hoisted_3, toDisplayString(__props.floor) + "F", 1)) : createCommentVNode("", true)
      ], 10, _hoisted_1);
    };
  }
};
export {
  _sfc_main as _
};
