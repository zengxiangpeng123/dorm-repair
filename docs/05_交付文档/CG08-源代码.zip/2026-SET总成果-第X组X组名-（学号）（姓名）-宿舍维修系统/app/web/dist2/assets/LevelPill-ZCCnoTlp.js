import { g as openBlock, c as createElementBlock, t as toDisplayString, d as createCommentVNode } from "./index-CQHsh9DN.js";
const _hoisted_1 = ["data-lv"];
const _sfc_main = {
  __name: "LevelPill",
  props: { level: { type: String, default: "" } },
  setup(__props) {
    return (_ctx, _cache) => {
      return __props.level ? (openBlock(), createElementBlock("span", {
        key: 0,
        class: "pill lv",
        "data-lv": __props.level
      }, toDisplayString(__props.level), 9, _hoisted_1)) : createCommentVNode("", true);
    };
  }
};
export {
  _sfc_main as _
};
