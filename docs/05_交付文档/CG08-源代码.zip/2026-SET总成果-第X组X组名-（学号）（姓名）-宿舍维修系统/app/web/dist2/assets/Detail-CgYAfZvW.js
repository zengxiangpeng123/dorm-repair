import { o as onMounted, h as onUnmounted, c as createElementBlock, a as createBaseVNode, u as unref, t as toDisplayString, i as createVNode, F as Fragment, r as renderList, d as createCommentVNode, n as normalizeClass, k as withModifiers, w as withDirectives, v as vModelText, l as useRoute, e as useRouter, f as ref, j as computed, g as openBlock, b as createTextVNode } from "./index-CQHsh9DN.js";
import { B as BottomNav } from "./BottomNav-wi4vEY3F.js";
import { _ as _sfc_main$2 } from "./StatusPill-KCmlmcRf.js";
import { _ as _sfc_main$1 } from "./LevelPill-ZCCnoTlp.js";
import { _ as _export_sfc, o as ordersApi, d as describeError } from "./_plugin-vue_export-helper-CJxN7Dmm.js";
import { b as shortWindow, s as shortLeft, E as EVENT, a as steps } from "./status-BDo8bc0j.js";
import { t as toneOf, a as timersOf } from "./timers-CbMtjaoE.js";
const _hoisted_1 = { class: "top" };
const _hoisted_2 = { class: "tiny muted num" };
const _hoisted_3 = {
  key: 0,
  class: "empty"
};
const _hoisted_4 = {
  key: 1,
  class: "empty"
};
const _hoisted_5 = {
  key: 2,
  class: "body has-dock"
};
const _hoisted_6 = { class: "card" };
const _hoisted_7 = { class: "between" };
const _hoisted_8 = { class: "loc" };
const _hoisted_9 = { class: "tiny muted" };
const _hoisted_10 = { class: "row" };
const _hoisted_11 = { class: "desc" };
const _hoisted_12 = { class: "steps" };
const _hoisted_13 = ["data-s"];
const _hoisted_14 = {
  key: 0,
  class: "card"
};
const _hoisted_15 = ["data-tone"];
const _hoisted_16 = { class: "lb" };
const _hoisted_17 = { class: "sub" };
const _hoisted_18 = { class: "val num" };
const _hoisted_19 = {
  class: "note",
  "data-tone": "info",
  style: { "margin-top": "9px" }
};
const _hoisted_20 = {
  key: 1,
  class: "card"
};
const _hoisted_21 = ["data-tone"];
const _hoisted_22 = { class: "lb" };
const _hoisted_23 = { class: "sub" };
const _hoisted_24 = { class: "val num" };
const _hoisted_25 = {
  class: "note",
  style: { "margin-top": "9px" }
};
const _hoisted_26 = { class: "card" };
const _hoisted_27 = { class: "kv" };
const _hoisted_28 = { class: "v" };
const _hoisted_29 = { class: "kv" };
const _hoisted_30 = { class: "v num" };
const _hoisted_31 = { class: "kv" };
const _hoisted_32 = { class: "v num" };
const _hoisted_33 = { class: "kv" };
const _hoisted_34 = { class: "v num" };
const _hoisted_35 = {
  key: 0,
  class: "kv"
};
const _hoisted_36 = { class: "v num" };
const _hoisted_37 = { class: "card" };
const _hoisted_38 = { class: "card-hd" };
const _hoisted_39 = { class: "hint" };
const _hoisted_40 = { class: "thumbs" };
const _hoisted_41 = {
  key: 0,
  class: "thumb",
  "data-tone": "bad"
};
const _hoisted_42 = {
  key: 1,
  class: "thumb"
};
const _hoisted_43 = {
  key: 0,
  class: "note",
  "data-tone": "bad",
  style: { "margin-top": "9px" }
};
const _hoisted_44 = {
  key: 2,
  class: "card"
};
const _hoisted_45 = { class: "card-hd" };
const _hoisted_46 = { class: "hint" };
const _hoisted_47 = { class: "money" };
const _hoisted_48 = { class: "n" };
const _hoisted_49 = { class: "n num" };
const _hoisted_50 = {
  key: 0,
  class: "note",
  "data-tone": "warn",
  style: { "margin-top": "9px" }
};
const _hoisted_51 = { class: "card" };
const _hoisted_52 = { class: "kv" };
const _hoisted_53 = { class: "v" };
const _hoisted_54 = { class: "kv" };
const _hoisted_55 = { class: "v" };
const _hoisted_56 = { class: "kv" };
const _hoisted_57 = { class: "v" };
const _hoisted_58 = { class: "card" };
const _hoisted_59 = { class: "card-hd" };
const _hoisted_60 = { class: "hint" };
const _hoisted_61 = { class: "tl" };
const _hoisted_62 = ["data-s"];
const _hoisted_63 = { class: "t num" };
const _hoisted_64 = { class: "d" };
const _hoisted_65 = {
  key: 0,
  class: "pill plain tiny",
  "data-st": "ASSIGNED"
};
const _hoisted_66 = { class: "tiny muted" };
const _hoisted_67 = {
  key: 3,
  class: "err"
};
const _hoisted_68 = {
  key: 4,
  class: "note",
  "data-tone": "warn"
};
const _hoisted_69 = {
  key: 3,
  class: "dock"
};
const _hoisted_70 = ["disabled"];
const _hoisted_71 = {
  key: 3,
  class: "readonly"
};
const _hoisted_72 = { class: "sheet" };
const _hoisted_73 = { class: "sheet-hd" };
const _hoisted_74 = {
  class: "note",
  "data-tone": "info",
  style: { "margin-top": "9px" }
};
const _hoisted_75 = { class: "chips" };
const _hoisted_76 = ["onClick"];
const _hoisted_77 = ["disabled"];
const _hoisted_78 = {
  key: 4,
  class: "err"
};
const _sfc_main = {
  __name: "Detail",
  setup(__props) {
    const route = useRoute();
    const router = useRouter();
    const no = route.params.no;
    const o = ref(null);
    const meta = ref(null);
    const events = ref([]);
    const loading = ref(true);
    const err = ref("");
    const busy = ref("");
    const nowTick = ref(Date.now());
    const sheet = ref(null);
    const form = ref({ signerName: "", reason: "" });
    let timer = null;
    const tm = computed(() => timersOf(o.value, meta.value));
    const stepList = computed(() => o.value ? steps(o.value) : []);
    const canCancel = computed(() => o.value && (o.value.status === "PENDING" || o.value.status === "ASSIGNED" && !o.value.arriveAt));
    const afterPhotos = computed(() => {
      var _a;
      return (((_a = o.value) == null ? void 0 : _a.photosAfter) || []).length;
    });
    const mismatch = computed(
      () => o.value && ["VERIFYING", "DONE", "CLOSED"].includes(o.value.status) && afterPhotos.value === 0
    );
    async function load() {
      try {
        const [d, m] = await Promise.all([ordersApi.detail(no), ordersApi.meta()]);
        o.value = d;
        meta.value = m;
        events.value = d.events || [];
        err.value = "";
      } catch (e) {
        err.value = describeError(e);
      } finally {
        loading.value = false;
      }
    }
    async function fire(path, body, tag) {
      busy.value = tag;
      err.value = "";
      try {
        const r = await path(o.value.no, { ...body, version: o.value.version });
        sheet.value = null;
        form.value = { signerName: "", reason: "" };
        if (tag === "reject" && r && r.no) {
          router.replace(`/student/detail/${r.no}`);
          return;
        }
        await load();
      } catch (e) {
        err.value = describeError(e);
        if (e.status === 409) load();
      } finally {
        busy.value = "";
      }
    }
    function openSheet(kind) {
      form.value = { signerName: o.value.studentName || "", reason: "" };
      sheet.value = kind;
    }
    function confirmSheet() {
      if (sheet.value === "accept") {
        if (!form.value.signerName.trim()) return;
        fire(ordersApi.accept, { signerName: form.value.signerName.trim() }, "accept");
      } else if (sheet.value === "reject") {
        if (form.value.reason.trim().length < 2) return;
        fire(ordersApi.reject, { reason: form.value.reason.trim() }, "reject");
      } else if (sheet.value === "cancel") {
        fire(ordersApi.cancel, { reason: form.value.reason.trim() || "不需要修了" }, "cancel");
      } else if (sheet.value === "cancelRequest") {
        if (form.value.reason.trim().length < 2) return;
        fire(ordersApi.cancelRequest, { reason: form.value.reason.trim() }, "cancelRequest");
      }
    }
    function fmtAt(s) {
      return s ? String(s).slice(5, 16) : "";
    }
    onMounted(() => {
      load();
      timer = setInterval(() => {
        nowTick.value = Date.now();
      }, 1e3);
    });
    onUnmounted(() => clearInterval(timer));
    return (_ctx, _cache) => {
      var _a, _b, _c, _d, _e, _f, _g;
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("header", _hoisted_1, [
          createBaseVNode("button", {
            class: "back",
            onClick: _cache[0] || (_cache[0] = ($event) => unref(router).push("/student/list"))
          }, "‹ 我的报修"),
          createBaseVNode("span", _hoisted_2, toDisplayString(unref(no)), 1)
        ]),
        loading.value ? (openBlock(), createElementBlock("div", _hoisted_3, "加载中…")) : !o.value ? (openBlock(), createElementBlock("div", _hoisted_4, toDisplayString(err.value || "找不到这张单"), 1)) : (openBlock(), createElementBlock("div", _hoisted_5, [
          createBaseVNode("div", _hoisted_6, [
            createBaseVNode("div", _hoisted_7, [
              createBaseVNode("div", null, [
                createBaseVNode("div", _hoisted_8, toDisplayString(o.value.building) + " " + toDisplayString(o.value.floor) + "F-" + toDisplayString(o.value.room), 1),
                createBaseVNode("div", _hoisted_9, toDisplayString(o.value.category) + " · " + toDisplayString(unref(shortWindow)(o.value.window) || "全天"), 1)
              ]),
              createBaseVNode("div", _hoisted_10, [
                createVNode(_sfc_main$1, {
                  level: o.value.level
                }, null, 8, ["level"]),
                createVNode(_sfc_main$2, {
                  status: o.value.status
                }, null, 8, ["status"])
              ])
            ]),
            createBaseVNode("p", _hoisted_11, toDisplayString(o.value.desc), 1),
            createBaseVNode("div", _hoisted_12, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(stepList.value, (s, i) => {
                return openBlock(), createElementBlock("div", {
                  key: i,
                  class: "st",
                  "data-s": s.state
                }, [
                  _cache[11] || (_cache[11] = createBaseVNode("i", null, null, -1)),
                  createBaseVNode("span", null, toDisplayString(s.label), 1)
                ], 8, _hoisted_13);
              }), 128))
            ])
          ]),
          tm.value.t1 ? (openBlock(), createElementBlock("div", _hoisted_14, [
            _cache[12] || (_cache[12] = createBaseVNode("div", { class: "card-hd" }, [
              createBaseVNode("h3", null, "学生还差多久自动验收"),
              createBaseVNode("span", { class: "hint" }, "T1")
            ], -1)),
            createBaseVNode("div", {
              class: "timerbox",
              "data-tone": unref(toneOf)(tm.value.t1.leftMs, tm.value.t1.total)
            }, [
              createBaseVNode("div", null, [
                createBaseVNode("div", _hoisted_16, toDisplayString(tm.value.t1.label), 1),
                createBaseVNode("div", _hoisted_17, "起点：师傅完工 " + toDisplayString(tm.value.t1.from), 1)
              ]),
              createBaseVNode("div", _hoisted_18, toDisplayString(unref(shortLeft)(tm.value.t1.leftMs)), 1)
            ], 8, _hoisted_15),
            createBaseVNode("div", _hoisted_19, " 满 " + toDisplayString(((_a = meta.value) == null ? void 0 : _a.verifyHours) ?? 168) + ' 小时没回应，系统自己确认完成，记成"系统自动"，不算人工。 ', 1)
          ])) : createCommentVNode("", true),
          tm.value.t2 ? (openBlock(), createElementBlock("div", _hoisted_20, [
            _cache[13] || (_cache[13] = createBaseVNode("div", { class: "card-hd" }, [
              createBaseVNode("h3", null, "这单还有多久归档"),
              createBaseVNode("span", { class: "hint" }, "T2")
            ], -1)),
            createBaseVNode("div", {
              class: "timerbox",
              "data-tone": unref(toneOf)(tm.value.t2.leftMs, tm.value.t2.total)
            }, [
              createBaseVNode("div", null, [
                createBaseVNode("div", _hoisted_22, toDisplayString(tm.value.t2.label), 1),
                createBaseVNode("div", _hoisted_23, "起点：学生签字 " + toDisplayString(tm.value.t2.from), 1)
              ]),
              createBaseVNode("div", _hoisted_24, toDisplayString(unref(shortLeft)(tm.value.t2.leftMs)), 1)
            ], 8, _hoisted_21),
            createBaseVNode("div", _hoisted_25, " 满 " + toDisplayString(((_b = meta.value) == null ? void 0 : _b.archiveDays) ?? 7) + " 天转只读。归档之后管理端才回看，不回改在办的单。 ", 1)
          ])) : createCommentVNode("", true),
          createBaseVNode("div", _hoisted_26, [
            _cache[19] || (_cache[19] = createBaseVNode("div", { class: "card-hd" }, [
              createBaseVNode("h3", null, "谁在处理")
            ], -1)),
            createBaseVNode("div", _hoisted_27, [
              _cache[14] || (_cache[14] = createBaseVNode("span", { class: "k" }, "师傅", -1)),
              createBaseVNode("span", _hoisted_28, toDisplayString(o.value.workerName || "还没派到"), 1)
            ]),
            createBaseVNode("div", _hoisted_29, [
              _cache[15] || (_cache[15] = createBaseVNode("span", { class: "k" }, "派工", -1)),
              createBaseVNode("span", _hoisted_30, toDisplayString(o.value.assignedAt || "—"), 1)
            ]),
            createBaseVNode("div", _hoisted_31, [
              _cache[16] || (_cache[16] = createBaseVNode("span", { class: "k" }, "到门", -1)),
              createBaseVNode("span", _hoisted_32, toDisplayString(o.value.arriveAt || "—"), 1)
            ]),
            createBaseVNode("div", _hoisted_33, [
              _cache[17] || (_cache[17] = createBaseVNode("span", { class: "k" }, "完工", -1)),
              createBaseVNode("span", _hoisted_34, toDisplayString(o.value.finishAt || "—"), 1)
            ]),
            o.value.signAt ? (openBlock(), createElementBlock("div", _hoisted_35, [
              _cache[18] || (_cache[18] = createBaseVNode("span", { class: "k" }, "签字", -1)),
              createBaseVNode("span", _hoisted_36, toDisplayString(o.value.signAt), 1)
            ])) : createCommentVNode("", true)
          ]),
          createBaseVNode("div", _hoisted_37, [
            createBaseVNode("div", _hoisted_38, [
              _cache[20] || (_cache[20] = createBaseVNode("h3", null, "照片", -1)),
              createBaseVNode("span", _hoisted_39, "现场 " + toDisplayString((o.value.photosBefore || []).length) + " 张 · 完工 " + toDisplayString(afterPhotos.value) + " 张", 1)
            ]),
            createBaseVNode("div", _hoisted_40, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(o.value.photosBefore, (p, i) => {
                return openBlock(), createElementBlock("div", {
                  key: p,
                  class: "thumb",
                  "data-tone": "ok"
                }, [
                  _cache[21] || (_cache[21] = createBaseVNode("span", null, "📷", -1)),
                  createBaseVNode("span", null, "现场 " + toDisplayString(i + 1), 1)
                ]);
              }), 128)),
              (openBlock(true), createElementBlock(Fragment, null, renderList(o.value.photosAfter, (p, i) => {
                return openBlock(), createElementBlock("div", {
                  key: p,
                  class: "thumb",
                  "data-tone": "ok"
                }, [
                  _cache[22] || (_cache[22] = createBaseVNode("span", null, "📸", -1)),
                  createBaseVNode("span", null, "完工 " + toDisplayString(i + 1), 1)
                ]);
              }), 128)),
              mismatch.value ? (openBlock(), createElementBlock("div", _hoisted_41, [..._cache[23] || (_cache[23] = [
                createBaseVNode("span", null, "⚠️", -1),
                createBaseVNode("span", null, "缺完工照", -1)
              ])])) : !afterPhotos.value ? (openBlock(), createElementBlock("div", _hoisted_42, [..._cache[24] || (_cache[24] = [
                createBaseVNode("span", null, "📷", -1),
                createBaseVNode("span", null, "等师傅上传", -1)
              ])])) : createCommentVNode("", true)
            ]),
            mismatch.value ? (openBlock(), createElementBlock("div", _hoisted_43, " 这单已经到「" + toDisplayString(o.value.statusLabel) + "」，但一张完工照都没有。它会出现在管理端「数据对不上」清单里。 ", 1)) : createCommentVNode("", true)
          ]),
          o.value.partsName ? (openBlock(), createElementBlock("div", _hoisted_44, [
            createBaseVNode("div", _hoisted_45, [
              _cache[25] || (_cache[25] = createBaseVNode("h3", null, "缺的配件", -1)),
              createBaseVNode("span", _hoisted_46, toDisplayString(o.value.partsEta || ""), 1)
            ]),
            createBaseVNode("div", _hoisted_47, [
              createBaseVNode("div", null, [
                createBaseVNode("div", _hoisted_48, toDisplayString(o.value.partsName), 1),
                _cache[26] || (_cache[26] = createBaseVNode("div", { class: "k" }, "配件", -1))
              ]),
              createBaseVNode("div", null, [
                createBaseVNode("div", {
                  class: normalizeClass(["n num", { hot: Number(o.value.partsAmount) > (((_c = meta.value) == null ? void 0 : _c.budgetLine) ?? 200) }])
                }, "¥" + toDisplayString(o.value.partsAmount), 3),
                _cache[27] || (_cache[27] = createBaseVNode("div", { class: "k" }, "金额", -1))
              ]),
              createBaseVNode("div", null, [
                createBaseVNode("div", _hoisted_49, "¥" + toDisplayString(((_d = meta.value) == null ? void 0 : _d.budgetLine) ?? 200), 1),
                _cache[28] || (_cache[28] = createBaseVNode("div", { class: "k" }, "预算线", -1))
              ])
            ]),
            Number(o.value.partsAmount) > (((_e = meta.value) == null ? void 0 : _e.budgetLine) ?? 200) ? (openBlock(), createElementBlock("div", _hoisted_50, " 超过预算线，这笔采购会进管理端「超预算采购」清单等审批。 ")) : createCommentVNode("", true)
          ])) : createCommentVNode("", true),
          createBaseVNode("div", _hoisted_51, [
            _cache[32] || (_cache[32] = createBaseVNode("div", { class: "card-hd" }, [
              createBaseVNode("h3", null, "系统怎么判的"),
              createBaseVNode("span", { class: "hint" }, "只读")
            ], -1)),
            createBaseVNode("div", _hoisted_52, [
              _cache[29] || (_cache[29] = createBaseVNode("span", { class: "k" }, "故障类型", -1)),
              createBaseVNode("span", _hoisted_53, toDisplayString(o.value.category), 1)
            ]),
            createBaseVNode("div", _hoisted_54, [
              _cache[30] || (_cache[30] = createBaseVNode("span", { class: "k" }, "紧急程度", -1)),
              createBaseVNode("span", _hoisted_55, toDisplayString(o.value.level) + "（" + toDisplayString(o.value.levelSource === "FALLBACK" ? "AI 不可用，走的兜底规则" : o.value.levelSource === "MANUAL" ? "人工指定" : "AI 判定") + "）", 1)
            ]),
            createBaseVNode("div", _hoisted_56, [
              _cache[31] || (_cache[31] = createBaseVNode("span", { class: "k" }, "判定依据", -1)),
              createBaseVNode("span", _hoisted_57, toDisplayString(o.value.aiBasis), 1)
            ]),
            _cache[33] || (_cache[33] = createBaseVNode("div", {
              class: "note",
              style: { "margin-top": "9px" }
            }, "判定依据不许事后改，改了就没法复盘 AI 准不准。", -1))
          ]),
          createBaseVNode("div", _hoisted_58, [
            createBaseVNode("div", _hoisted_59, [
              _cache[34] || (_cache[34] = createBaseVNode("h3", null, "这单经过", -1)),
              createBaseVNode("span", _hoisted_60, "共 " + toDisplayString(events.value.length) + " 步", 1)
            ]),
            createBaseVNode("div", _hoisted_61, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(events.value, (e, i) => {
                return openBlock(), createElementBlock("div", {
                  key: e.seq || i,
                  class: "ev",
                  "data-s": i === events.value.length - 1 ? "now" : "done"
                }, [
                  createBaseVNode("div", _hoisted_63, toDisplayString(fmtAt(e.at)), 1),
                  createBaseVNode("div", _hoisted_64, [
                    createTextVNode(toDisplayString(unref(EVENT)[e.event] || e.event) + " ", 1),
                    e.manual === 0 ? (openBlock(), createElementBlock("span", _hoisted_65, "系统自动")) : createCommentVNode("", true)
                  ]),
                  createBaseVNode("div", _hoisted_66, toDisplayString(e.actorName) + toDisplayString(e.note ? " · " + e.note : ""), 1)
                ], 8, _hoisted_62);
              }), 128))
            ])
          ]),
          err.value ? (openBlock(), createElementBlock("p", _hoisted_67, toDisplayString(err.value), 1)) : createCommentVNode("", true),
          o.value.cancelRequestAt || o.value.status === "REPAIRING" ? (openBlock(), createElementBlock("div", _hoisted_68, " 师傅已经进楼了，这单你自己撤不了。要撤就点「申请撤销」，管理员看了再决定作废还是补师傅工钱。 ")) : createCommentVNode("", true)
        ])),
        o.value ? (openBlock(), createElementBlock("div", _hoisted_69, [
          canCancel.value ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
            createBaseVNode("button", {
              class: "dbtn ghost",
              onClick: _cache[1] || (_cache[1] = ($event) => openSheet("cancel"))
            }, "撤销报修"),
            createBaseVNode("button", {
              class: "dbtn primary",
              onClick: _cache[2] || (_cache[2] = ($event) => unref(router).push("/student/list"))
            }, "回到列表")
          ], 64)) : o.value.status === "REPAIRING" ? (openBlock(), createElementBlock("button", {
            key: 1,
            class: "dbtn",
            disabled: busy.value === "cancelRequest",
            onClick: _cache[3] || (_cache[3] = ($event) => openSheet("cancelRequest"))
          }, toDisplayString(busy.value === "cancelRequest" ? "提交中…" : "申请撤销"), 9, _hoisted_70)) : o.value.status === "VERIFYING" ? (openBlock(), createElementBlock(Fragment, { key: 2 }, [
            createBaseVNode("button", {
              class: "dbtn ghost",
              onClick: _cache[4] || (_cache[4] = ($event) => openSheet("reject"))
            }, "还没修好"),
            createBaseVNode("button", {
              class: "dbtn primary",
              onClick: _cache[5] || (_cache[5] = ($event) => openSheet("accept"))
            }, "确认修好并签字")
          ], 64)) : (openBlock(), createElementBlock("div", _hoisted_71, toDisplayString(o.value.statusLabel) + toDisplayString(o.value.status === "DONE" ? " · 还在归档倒计时里" : o.value.status === "CLOSED" ? " · 已归档只读" : ""), 1))
        ])) : createCommentVNode("", true),
        sheet.value ? (openBlock(), createElementBlock("div", {
          key: 4,
          class: "mask",
          onClick: _cache[10] || (_cache[10] = withModifiers(($event) => sheet.value = null, ["self"]))
        }, [
          createBaseVNode("div", _hoisted_72, [
            createBaseVNode("div", _hoisted_73, [
              createBaseVNode("b", null, toDisplayString(sheet.value === "accept" ? "确认修好并签字" : sheet.value === "reject" ? "还没修好" : sheet.value === "cancel" ? "撤销报修" : "申请撤销"), 1),
              createBaseVNode("button", {
                onClick: _cache[6] || (_cache[6] = ($event) => sheet.value = null)
              }, "取消")
            ]),
            sheet.value === "accept" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
              _cache[35] || (_cache[35] = createBaseVNode("label", { class: "lb" }, "签字人", -1)),
              withDirectives(createBaseVNode("input", {
                "onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => form.value.signerName = $event),
                class: "in",
                placeholder: "签谁的名字"
              }, null, 512), [
                [vModelText, form.value.signerName]
              ]),
              createBaseVNode("p", _hoisted_74, " 签完这单就完成，开始算 " + toDisplayString(((_f = meta.value) == null ? void 0 : _f.archiveDays) ?? 7) + " 天归档倒计时。签完不能再改。 ", 1)
            ], 64)) : sheet.value === "reject" ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [
              _cache[36] || (_cache[36] = createBaseVNode("label", { class: "lb" }, "哪儿还不行", -1)),
              withDirectives(createBaseVNode("textarea", {
                "onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => form.value.reason = $event),
                rows: "3",
                class: "in ta",
                placeholder: "举个例子：还在滴水，地上还是湿的"
              }, null, 512), [
                [vModelText, form.value.reason]
              ]),
              _cache[37] || (_cache[37] = createBaseVNode("p", {
                class: "note",
                "data-tone": "warn",
                style: { "margin-top": "9px" }
              }, " 打回会生成一张返修单（-R1），紧急程度升一档，原单的历史和照片都带过去。 ", -1))
            ], 64)) : sheet.value === "cancel" ? (openBlock(), createElementBlock(Fragment, { key: 2 }, [
              _cache[38] || (_cache[38] = createBaseVNode("label", { class: "lb" }, "为什么撤（可不写）", -1)),
              createBaseVNode("div", _hoisted_75, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(((_g = meta.value) == null ? void 0 : _g.cancelReasons) || ["不需要修了", "重复报修", "自己已经修好", "信息填错"], (r) => {
                  return openBlock(), createElementBlock("button", {
                    key: r,
                    class: normalizeClass(["chip", { on: form.value.reason === r }]),
                    onClick: ($event) => form.value.reason = r
                  }, toDisplayString(r), 11, _hoisted_76);
                }), 128))
              ]),
              _cache[39] || (_cache[39] = createBaseVNode("p", {
                class: "note",
                style: { "margin-top": "9px" }
              }, "师傅还没上门，撤了就是撤了，不计入任何考核。", -1))
            ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 3 }, [
              _cache[40] || (_cache[40] = createBaseVNode("label", { class: "lb" }, "情况说明", -1)),
              withDirectives(createBaseVNode("textarea", {
                "onUpdate:modelValue": _cache[9] || (_cache[9] = ($event) => form.value.reason = $event),
                rows: "3",
                class: "in ta",
                placeholder: "师傅已经进楼了，说明一下为什么想撤"
              }, null, 512), [
                [vModelText, form.value.reason]
              ]),
              _cache[41] || (_cache[41] = createBaseVNode("p", {
                class: "note",
                "data-tone": "warn",
                style: { "margin-top": "9px" }
              }, " 这条不改状态，只是把申请记下来给管理员看。作废还是给师傅补工钱，由管理员决定（接口在这个分支返回 501，等变更单 CR-001）。 ", -1))
            ], 64)),
            createBaseVNode("button", {
              class: "submit",
              disabled: !!busy.value || sheet.value === "accept" && !form.value.signerName.trim() || (sheet.value === "reject" || sheet.value === "cancelRequest") && form.value.reason.trim().length < 2,
              onClick: confirmSheet
            }, toDisplayString(busy.value ? "提交中…" : "确定"), 9, _hoisted_77),
            err.value ? (openBlock(), createElementBlock("p", _hoisted_78, toDisplayString(err.value), 1)) : createCommentVNode("", true)
          ])
        ])) : createCommentVNode("", true),
        createVNode(BottomNav, { role: "student" })
      ], 64);
    };
  }
};
const Detail = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-60cdbc64"]]);
export {
  Detail as default
};
