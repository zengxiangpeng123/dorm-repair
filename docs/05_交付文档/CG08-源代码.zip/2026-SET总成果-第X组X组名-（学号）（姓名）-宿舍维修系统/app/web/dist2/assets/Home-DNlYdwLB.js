import { o as onMounted, c as createElementBlock, a as createBaseVNode, k as withModifiers, b as createTextVNode, t as toDisplayString, d as createCommentVNode, F as Fragment, r as renderList, m as createStaticVNode, u as unref, w as withDirectives, v as vModelText, f as ref, j as computed, e as useRouter, g as openBlock, i as createVNode } from "./index-CQHsh9DN.js";
import { _ as _sfc_main$2 } from "./StatusPill-KCmlmcRf.js";
import { _ as _sfc_main$1 } from "./LevelPill-ZCCnoTlp.js";
import { _ as _export_sfc, o as ordersApi, d as describeError } from "./_plugin-vue_export-helper-CJxN7Dmm.js";
import { s as shortLeft } from "./status-BDo8bc0j.js";
import { a as timersOf } from "./timers-CbMtjaoE.js";
const _hoisted_1 = { class: "desk" };
const _hoisted_2 = { class: "desk-side" };
const _hoisted_3 = { class: "desk-main" };
const _hoisted_4 = { class: "desk-top" };
const _hoisted_5 = { class: "t2" };
const _hoisted_6 = ["disabled"];
const _hoisted_7 = ["disabled"];
const _hoisted_8 = { class: "desk-wrap" };
const _hoisted_9 = {
  key: 0,
  class: "err"
};
const _hoisted_10 = { class: "strip" };
const _hoisted_11 = { class: "num" };
const _hoisted_12 = { class: "num" };
const _hoisted_13 = { class: "num" };
const _hoisted_14 = { class: "num" };
const _hoisted_15 = { class: "k" };
const _hoisted_16 = { class: "hint-inline" };
const _hoisted_17 = { class: "row2" };
const _hoisted_18 = { class: "panel" };
const _hoisted_19 = { class: "dt" };
const _hoisted_20 = { class: "num" };
const _hoisted_21 = {
  key: 0,
  class: "mini"
};
const _hoisted_22 = {
  key: 0,
  class: "timer-inline num"
};
const _hoisted_23 = { class: "r num" };
const _hoisted_24 = { class: "panel" };
const _hoisted_25 = { class: "pn" };
const _hoisted_26 = { class: "ln1" };
const _hoisted_27 = { class: "pill plain tag" };
const _hoisted_28 = { class: "num" };
const _hoisted_29 = { class: "loc" };
const _hoisted_30 = { class: "why" };
const _hoisted_31 = { class: "acts" };
const _hoisted_32 = ["onClick"];
const _hoisted_33 = {
  key: 1,
  class: "then"
};
const _hoisted_34 = {
  key: 0,
  class: "empty"
};
const _hoisted_35 = { class: "row2" };
const _hoisted_36 = { class: "col" };
const _hoisted_37 = { class: "panel" };
const _hoisted_38 = { class: "dt" };
const _hoisted_39 = { class: "r num" };
const _hoisted_40 = { class: "r num" };
const _hoisted_41 = { class: "r num" };
const _hoisted_42 = { class: "panel" };
const _hoisted_43 = { class: "dt" };
const _hoisted_44 = { class: "num" };
const _hoisted_45 = { class: "r num" };
const _hoisted_46 = { class: "r num" };
const _hoisted_47 = { class: "panel" };
const _hoisted_48 = { class: "dt" };
const _hoisted_49 = { class: "num" };
const _hoisted_50 = { class: "num tiny" };
const _hoisted_51 = { class: "r num" };
const _hoisted_52 = { class: "col" };
const _hoisted_53 = { class: "panel" };
const _hoisted_54 = { class: "panel-foot" };
const _hoisted_55 = { class: "panel" };
const _hoisted_56 = { class: "hint" };
const _hoisted_57 = { class: "pn" };
const _hoisted_58 = { class: "cfg" };
const _hoisted_59 = ["disabled"];
const _hoisted_60 = { class: "foot-note warn" };
const _hoisted_61 = {
  key: 0,
  class: "toast"
};
const _sfc_main = {
  __name: "Home",
  setup(__props) {
    const router = useRouter();
    const dash = ref(null);
    const ex = ref(null);
    const orders = ref([]);
    const cfg = ref(null);
    const meta = ref(null);
    const err = ref("");
    const busy = ref("");
    const cfgDraft = ref({});
    const kindLabel = computed(() => {
      var _a;
      const m = {};
      for (const k of ((_a = meta.value) == null ? void 0 : _a.exceptionKinds) || []) m[k.code] = k.label;
      return m;
    });
    const active = computed(() => orders.value.filter((o) => !["CLOSED", "CANCELLED"].includes(o.status)));
    const archive = computed(() => orders.value.filter((o) => ["DONE", "CLOSED"].includes(o.status)).slice(0, 6));
    function leftOf(o) {
      const t = timersOf(o, meta.value);
      const one = t.t1 || t.t2;
      if (!one) return "";
      return `${t.t1 ? "T1" : "T2"} ${shortLeft(one.leftMs)}`;
    }
    function manualCount(o) {
      return (o.events || []).filter((e) => e.manual === 1).length;
    }
    async function load() {
      try {
        const [d, e, o, c, m] = await Promise.all([
          ordersApi.dashboard(),
          ordersApi.exceptions(),
          ordersApi.list({ pageSize: 200 }),
          ordersApi.config(),
          ordersApi.meta()
        ]);
        dash.value = d;
        ex.value = e;
        orders.value = o.items || o || [];
        cfg.value = c;
        cfgDraft.value = { budgetLine: c.budgetLine, verifyHours: c.verifyHours, archiveDays: c.archiveDays };
        meta.value = m;
        err.value = "";
      } catch (e2) {
        err.value = describeError(e2);
      }
    }
    async function advance(hours = 168) {
      busy.value = "advance";
      try {
        const r = await ordersApi.advance(hours);
        await load();
        err.value = "";
        keeper.value = `快进 ${hours} 小时：自动验收 ${(r.autoAccepted || []).length} 张，归档 ${(r.archived || []).length} 张`;
      } catch (e2) {
        err.value = describeError(e2);
      } finally {
        busy.value = "";
      }
    }
    async function resetDemo() {
      busy.value = "reset";
      try {
        await ordersApi.reset();
        await load();
        err.value = "";
        keeper.value = "演示数据已重灌";
      } catch (e2) {
        err.value = describeError(e2);
      } finally {
        busy.value = "";
      }
    }
    async function saveCfg() {
      busy.value = "cfg";
      err.value = "";
      try {
        cfg.value = await ordersApi.saveConfig(cfgDraft.value);
        await load();
      } catch (e) {
        err.value = describeError(e);
      } finally {
        busy.value = "";
      }
    }
    async function tryCancel(item) {
      busy.value = item.no;
      err.value = "";
      try {
        await ordersApi.adminCancel(item.no, { version: item.version }, { role: "admin" });
      } catch (e) {
        err.value = describeError(e);
      } finally {
        busy.value = "";
      }
    }
    function keep(item) {
      busy.value = "";
      window.setTimeout(() => {
      }, 0);
      alertKeeper(item);
    }
    const keeper = ref("");
    function alertKeeper(item) {
      keeper.value = `${item.no} 先不动，等师傅报完工再看过`;
      window.clearTimeout(keeperTimer);
      keeperTimer = window.setTimeout(() => {
        keeper.value = "";
      }, 2600);
    }
    let keeperTimer = null;
    onMounted(load);
    return (_ctx, _cache) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q;
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("aside", _hoisted_2, [
          _cache[9] || (_cache[9] = createBaseVNode("div", { class: "brand" }, [
            createBaseVNode("div", { class: "logo" }, "修"),
            createBaseVNode("div", null, [
              createBaseVNode("div", { class: "bt" }, "宿舍维修系统"),
              createBaseVNode("div", { class: "bs" }, "后勤维修部 · 管理端")
            ])
          ], -1)),
          createBaseVNode("nav", null, [
            _cache[8] || (_cache[8] = createBaseVNode("a", {
              href: "#",
              class: "on"
            }, "监测台", -1)),
            createBaseVNode("a", {
              href: "#",
              onClick: _cache[0] || (_cache[0] = withModifiers(($event) => unref(router).push("/lab"), ["prevent"]))
            }, "状态机自检台"),
            createBaseVNode("a", {
              href: "#",
              onClick: _cache[1] || (_cache[1] = withModifiers(($event) => unref(router).push("/"), ["prevent"]))
            }, "回到三端入口")
          ]),
          _cache[10] || (_cache[10] = createBaseVNode("div", { class: "side-foot" }, [
            createTextVNode(" 督察守则：不派工、不审批、不催办。"),
            createBaseVNode("br"),
            createTextVNode("只在四类例外里出手。 ")
          ], -1))
        ]),
        createBaseVNode("main", _hoisted_3, [
          createBaseVNode("div", _hoisted_4, [
            createBaseVNode("div", null, [
              _cache[11] || (_cache[11] = createBaseVNode("div", { class: "t1" }, "监测台", -1)),
              createBaseVNode("div", _hoisted_5, "在办 " + toDisplayString(((_a = dash.value) == null ? void 0 : _a.active) ?? "—") + " 单 · 例外 " + toDisplayString(((_b = ex.value) == null ? void 0 : _b.total) ?? 0) + " 条 · 更新于 " + toDisplayString((/* @__PURE__ */ new Date()).toLocaleTimeString("zh-CN", { hour12: false })), 1)
            ]),
            _cache[12] || (_cache[12] = createBaseVNode("div", { class: "sp" }, null, -1)),
            _cache[13] || (_cache[13] = createBaseVNode("div", { class: "who" }, "后勤维修部 · 王主任", -1)),
            createBaseVNode("button", {
              class: "dbtn",
              onClick: load
            }, "刷新"),
            createBaseVNode("button", {
              class: "dbtn",
              disabled: busy.value === "advance",
              onClick: _cache[2] || (_cache[2] = ($event) => advance(168))
            }, "快进 168 小时", 8, _hoisted_6),
            createBaseVNode("button", {
              class: "dbtn",
              disabled: busy.value === "reset",
              onClick: resetDemo
            }, "重置演示数据", 8, _hoisted_7)
          ]),
          createBaseVNode("div", _hoisted_8, [
            err.value ? (openBlock(), createElementBlock("p", _hoisted_9, toDisplayString(err.value), 1)) : createCommentVNode("", true),
            createBaseVNode("div", _hoisted_10, [
              createBaseVNode("div", null, [
                createBaseVNode("div", _hoisted_11, toDisplayString(((_c = dash.value) == null ? void 0 : _c.active) ?? "—"), 1),
                _cache[14] || (_cache[14] = createBaseVNode("div", { class: "k" }, "在办", -1))
              ]),
              createBaseVNode("div", null, [
                createBaseVNode("div", _hoisted_12, toDisplayString(((_d = dash.value) == null ? void 0 : _d.pendingArchive) ?? "—"), 1),
                _cache[15] || (_cache[15] = createBaseVNode("div", { class: "k" }, "待归档", -1))
              ]),
              createBaseVNode("div", null, [
                createBaseVNode("div", _hoisted_13, toDisplayString(((_e = ex.value) == null ? void 0 : _e.total) ?? "—"), 1),
                _cache[16] || (_cache[16] = createBaseVNode("div", { class: "k" }, "例外待看", -1))
              ]),
              createBaseVNode("div", null, [
                createBaseVNode("div", _hoisted_14, toDisplayString(dash.value ? Math.round((((_f = dash.value.zeroManual) == null ? void 0 : _f.rate) ?? 0) * 100) : "—") + "%", 1),
                createBaseVNode("div", _hoisted_15, [
                  createTextVNode(" 零人工完成率（" + toDisplayString(((_h = (_g = dash.value) == null ? void 0 : _g.zeroManual) == null ? void 0 : _h.zero) ?? 0) + "/" + toDisplayString(((_j = (_i = dash.value) == null ? void 0 : _i.zeroManual) == null ? void 0 : _j.total) ?? 0) + " 张） ", 1),
                  createBaseVNode("span", _hoisted_16, "严格口径 " + toDisplayString(dash.value ? Math.round((((_k = dash.value.strictZero) == null ? void 0 : _k.rate) ?? 0) * 100) : "—") + "%", 1)
                ])
              ])
            ]),
            createBaseVNode("div", _hoisted_17, [
              createBaseVNode("section", _hoisted_18, [
                _cache[18] || (_cache[18] = createBaseVNode("header", null, [
                  createBaseVNode("b", null, "在办工单"),
                  createBaseVNode("span", { class: "spacer" }),
                  createBaseVNode("span", { class: "hint" }, "按楼层倒序 · 只读")
                ], -1)),
                createBaseVNode("table", _hoisted_19, [
                  _cache[17] || (_cache[17] = createBaseVNode("thead", null, [
                    createBaseVNode("tr", null, [
                      createBaseVNode("th", null, "单号"),
                      createBaseVNode("th", null, "位置"),
                      createBaseVNode("th", null, "故障"),
                      createBaseVNode("th", null, "紧急"),
                      createBaseVNode("th", null, "状态"),
                      createBaseVNode("th", null, "师傅"),
                      createBaseVNode("th", { class: "r" }, "状态时间")
                    ])
                  ], -1)),
                  createBaseVNode("tbody", null, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(active.value, (o) => {
                      return openBlock(), createElementBlock("tr", {
                        key: o.no
                      }, [
                        createBaseVNode("td", _hoisted_20, [
                          createTextVNode(toDisplayString(o.no) + " ", 1),
                          o.reworkOf ? (openBlock(), createElementBlock("span", _hoisted_21, "R" + toDisplayString(o.reworkIndex), 1)) : createCommentVNode("", true)
                        ]),
                        createBaseVNode("td", null, toDisplayString(o.building) + " " + toDisplayString(o.floor) + "F-" + toDisplayString(o.room), 1),
                        createBaseVNode("td", null, toDisplayString(o.category), 1),
                        createBaseVNode("td", null, [
                          createVNode(_sfc_main$1, {
                            level: o.level
                          }, null, 8, ["level"])
                        ]),
                        createBaseVNode("td", null, [
                          createVNode(_sfc_main$2, {
                            status: o.status
                          }, null, 8, ["status"]),
                          leftOf(o) ? (openBlock(), createElementBlock("span", _hoisted_22, toDisplayString(leftOf(o)), 1)) : createCommentVNode("", true)
                        ]),
                        createBaseVNode("td", null, toDisplayString(o.workerName || "—"), 1),
                        createBaseVNode("td", _hoisted_23, toDisplayString(o.statusAt ? String(o.statusAt).slice(5, 16) : "—"), 1)
                      ]);
                    }), 128))
                  ])
                ]),
                _cache[19] || (_cache[19] = createBaseVNode("div", { class: "panel-foot" }, " 排队：安全闸 → 截止时间 → 紧急度 → 先来先修。楼栋只用来攒批，不参与排队先后。 ", -1))
              ]),
              createBaseVNode("section", _hoisted_24, [
                _cache[21] || (_cache[21] = createBaseVNode("header", null, [
                  createBaseVNode("b", null, "例外待看"),
                  createBaseVNode("span", { class: "spacer" }),
                  createBaseVNode("span", { class: "hint" }, "四类之外一律不露")
                ], -1)),
                createBaseVNode("div", _hoisted_25, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(((_l = ex.value) == null ? void 0 : _l.items) || [], (it) => {
                    return openBlock(), createElementBlock("div", {
                      key: it.id,
                      class: "ex-row"
                    }, [
                      createBaseVNode("div", _hoisted_26, [
                        createBaseVNode("span", _hoisted_27, toDisplayString(kindLabel.value[it.kind] || it.kind), 1),
                        createBaseVNode("b", _hoisted_28, toDisplayString(it.no), 1),
                        createBaseVNode("span", _hoisted_29, toDisplayString(it.building) + " " + toDisplayString(it.floor) + "F-" + toDisplayString(it.room), 1)
                      ]),
                      createBaseVNode("div", _hoisted_30, toDisplayString(it.detail), 1),
                      createBaseVNode("div", _hoisted_31, [
                        it.kind === "CANCEL_REQUEST" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                          _cache[20] || (_cache[20] = createBaseVNode("button", {
                            class: "dbtn sm",
                            disabled: ""
                          }, "批准撤销（501）", -1)),
                          createBaseVNode("button", {
                            class: "dbtn sm ghost",
                            onClick: ($event) => keep(it)
                          }, "先不动", 8, _hoisted_32)
                        ], 64)) : (openBlock(), createElementBlock("span", _hoisted_33, "往哪儿看：先看单据和照片，别直接改在办单"))
                      ])
                    ]);
                  }), 128)),
                  !((_n = (_m = ex.value) == null ? void 0 : _m.items) == null ? void 0 : _n.length) ? (openBlock(), createElementBlock("div", _hoisted_34, "今天没有例外。管理端大部分时间是空的，这就是目标。")) : createCommentVNode("", true)
                ]),
                _cache[22] || (_cache[22] = createBaseVNode("div", { class: "panel-foot" }, " 前三类不占状态位；只有「学生申请撤销」能改状态，且要过变更单 CR-001。 ", -1))
              ])
            ]),
            createBaseVNode("div", _hoisted_35, [
              createBaseVNode("div", _hoisted_36, [
                createBaseVNode("section", _hoisted_37, [
                  _cache[24] || (_cache[24] = createBaseVNode("header", null, [
                    createBaseVNode("b", null, "楼栋台账"),
                    createBaseVNode("span", { class: "spacer" }),
                    createBaseVNode("span", { class: "hint" }, "事后回看用")
                  ], -1)),
                  createBaseVNode("table", _hoisted_38, [
                    _cache[23] || (_cache[23] = createBaseVNode("thead", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("th", null, "楼栋"),
                        createBaseVNode("th", { class: "r" }, "在办"),
                        createBaseVNode("th", { class: "r" }, "已完成"),
                        createBaseVNode("th", { class: "r" }, "例外")
                      ])
                    ], -1)),
                    createBaseVNode("tbody", null, [
                      (openBlock(true), createElementBlock(Fragment, null, renderList(((_o = dash.value) == null ? void 0 : _o.byBuilding) || [], (b) => {
                        return openBlock(), createElementBlock("tr", {
                          key: b.buildingId
                        }, [
                          createBaseVNode("td", null, toDisplayString(b.buildingName), 1),
                          createBaseVNode("td", _hoisted_39, toDisplayString(b.active), 1),
                          createBaseVNode("td", _hoisted_40, toDisplayString(b.done), 1),
                          createBaseVNode("td", _hoisted_41, toDisplayString(b.exceptions), 1)
                        ]);
                      }), 128))
                    ])
                  ])
                ]),
                createBaseVNode("section", _hoisted_42, [
                  _cache[26] || (_cache[26] = createBaseVNode("header", null, [
                    createBaseVNode("b", null, "最近归档"),
                    createBaseVNode("span", { class: "spacer" }),
                    createBaseVNode("span", { class: "hint" }, "归档之后才回看，不回改在办单")
                  ], -1)),
                  createBaseVNode("table", _hoisted_43, [
                    _cache[25] || (_cache[25] = createBaseVNode("thead", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("th", null, "单号"),
                        createBaseVNode("th", null, "位置"),
                        createBaseVNode("th", null, "状态"),
                        createBaseVNode("th", { class: "r" }, "返修"),
                        createBaseVNode("th", { class: "r" }, "人工介入")
                      ])
                    ], -1)),
                    createBaseVNode("tbody", null, [
                      (openBlock(true), createElementBlock(Fragment, null, renderList(archive.value, (o) => {
                        return openBlock(), createElementBlock("tr", {
                          key: o.no
                        }, [
                          createBaseVNode("td", _hoisted_44, toDisplayString(o.no), 1),
                          createBaseVNode("td", null, toDisplayString(o.building) + " " + toDisplayString(o.floor) + "F-" + toDisplayString(o.room), 1),
                          createBaseVNode("td", null, [
                            createVNode(_sfc_main$2, {
                              status: o.status
                            }, null, 8, ["status"])
                          ]),
                          createBaseVNode("td", _hoisted_45, toDisplayString(o.reworkCount || 0), 1),
                          createBaseVNode("td", _hoisted_46, toDisplayString(manualCount(o)) + " 步", 1)
                        ]);
                      }), 128))
                    ])
                  ])
                ]),
                createBaseVNode("section", _hoisted_47, [
                  _cache[28] || (_cache[28] = createBaseVNode("header", null, [
                    createBaseVNode("b", null, "两颗计时器"),
                    createBaseVNode("span", { class: "spacer" }),
                    createBaseVNode("span", { class: "hint" }, "起点不一样，各算各的")
                  ], -1)),
                  createBaseVNode("table", _hoisted_48, [
                    _cache[27] || (_cache[27] = createBaseVNode("thead", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("th", null, "单号"),
                        createBaseVNode("th", null, "位置"),
                        createBaseVNode("th", null, "哪颗"),
                        createBaseVNode("th", null, "起点"),
                        createBaseVNode("th", { class: "r" }, "还剩")
                      ])
                    ], -1)),
                    createBaseVNode("tbody", null, [
                      (openBlock(true), createElementBlock(Fragment, null, renderList(((_p = dash.value) == null ? void 0 : _p.timers) || [], (t) => {
                        var _a2, _b2, _c2;
                        return openBlock(), createElementBlock("tr", {
                          key: t.no + (t.t1 ? "a" : "b")
                        }, [
                          createBaseVNode("td", _hoisted_49, toDisplayString(t.no), 1),
                          createBaseVNode("td", null, toDisplayString(t.room), 1),
                          createBaseVNode("td", null, toDisplayString((_a2 = t.t1 || t.t2) == null ? void 0 : _a2.label), 1),
                          createBaseVNode("td", _hoisted_50, toDisplayString((_b2 = t.t1 || t.t2) == null ? void 0 : _b2.from), 1),
                          createBaseVNode("td", _hoisted_51, toDisplayString(unref(shortLeft)((_c2 = t.t1 || t.t2) == null ? void 0 : _c2.leftMs)), 1)
                        ]);
                      }), 128))
                    ])
                  ]),
                  _cache[29] || (_cache[29] = createBaseVNode("div", { class: "panel-foot" }, "T1 从师傅完工起算；T2 从学生签字起算。同一张单不会同时有两颗表。", -1))
                ])
              ]),
              createBaseVNode("div", _hoisted_52, [
                createBaseVNode("section", _hoisted_53, [
                  _cache[31] || (_cache[31] = createStaticVNode('<header data-v-094f6d7c><b data-v-094f6d7c>口径与介入点</b><span class="spacer" data-v-094f6d7c></span><span class="hint" data-v-094f6d7c>SYS-004</span></header><div class="pn" data-v-094f6d7c><div class="rule-row" data-v-094f6d7c><span class="n" data-v-094f6d7c>①</span><div data-v-094f6d7c><b data-v-094f6d7c>建单判不出来</b><div class="why" data-v-094f6d7c>AI 置信度低就往急里判并留依据，不拦单。</div></div></div><div class="rule-row" data-v-094f6d7c><span class="n" data-v-094f6d7c>②</span><div data-v-094f6d7c><b data-v-094f6d7c>缺件超预算</b><div class="why" data-v-094f6d7c>金额超预算线进清单，事前就知道花多少。</div></div></div><div class="rule-row" data-v-094f6d7c><span class="n" data-v-094f6d7c>③</span><div data-v-094f6d7c><b data-v-094f6d7c>同一单第 2 次返修</b><div class="why" data-v-094f6d7c>返修到第 2 次才让人看，第 1 次不算。</div></div></div><div class="rule-row" data-v-094f6d7c><span class="n" data-v-094f6d7c>④</span><div data-v-094f6d7c><b data-v-094f6d7c>学生申请撤销</b><div class="why" data-v-094f6d7c>师傅已进楼才有的情况，唯一能改状态的入口。</div></div></div></div>', 2)),
                  createBaseVNode("div", _hoisted_54, [
                    _cache[30] || (_cache[30] = createTextVNode("9 个状态、13 条转移。", -1)),
                    createBaseVNode("button", {
                      class: "link",
                      onClick: _cache[3] || (_cache[3] = ($event) => unref(router).push("/lab"))
                    }, "去自检台推一条试试 ›")
                  ])
                ]),
                createBaseVNode("section", _hoisted_55, [
                  createBaseVNode("header", null, [
                    _cache[32] || (_cache[32] = createBaseVNode("b", null, "可调参数", -1)),
                    _cache[33] || (_cache[33] = createBaseVNode("span", { class: "spacer" }, null, -1)),
                    createBaseVNode("span", _hoisted_56, "来源 " + toDisplayString(((_q = cfg.value) == null ? void 0 : _q.source) || "—"), 1)
                  ]),
                  createBaseVNode("div", _hoisted_57, [
                    createBaseVNode("div", _hoisted_58, [
                      createBaseVNode("label", null, [
                        _cache[34] || (_cache[34] = createTextVNode("预算线（元）", -1)),
                        withDirectives(createBaseVNode("input", {
                          "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => cfgDraft.value.budgetLine = $event),
                          class: "in num"
                        }, null, 512), [
                          [
                            vModelText,
                            cfgDraft.value.budgetLine,
                            void 0,
                            { number: true }
                          ]
                        ])
                      ]),
                      createBaseVNode("label", null, [
                        _cache[35] || (_cache[35] = createTextVNode("验收超时（小时）", -1)),
                        withDirectives(createBaseVNode("input", {
                          "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => cfgDraft.value.verifyHours = $event),
                          class: "in num"
                        }, null, 512), [
                          [
                            vModelText,
                            cfgDraft.value.verifyHours,
                            void 0,
                            { number: true }
                          ]
                        ])
                      ]),
                      createBaseVNode("label", null, [
                        _cache[36] || (_cache[36] = createTextVNode("归档天数", -1)),
                        withDirectives(createBaseVNode("input", {
                          "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => cfgDraft.value.archiveDays = $event),
                          class: "in num"
                        }, null, 512), [
                          [
                            vModelText,
                            cfgDraft.value.archiveDays,
                            void 0,
                            { number: true }
                          ]
                        ])
                      ])
                    ]),
                    createBaseVNode("button", {
                      class: "dbtn primary",
                      disabled: busy.value === "cfg",
                      onClick: saveCfg
                    }, toDisplayString(busy.value === "cfg" ? "保存中…" : "保存"), 9, _hoisted_59),
                    _cache[37] || (_cache[37] = createBaseVNode("div", {
                      class: "why",
                      style: { "margin-top": "8px" }
                    }, "存进 t_config，改完立刻生效，不用重启。", -1))
                  ])
                ])
              ])
            ]),
            createBaseVNode("div", _hoisted_60, [
              _cache[38] || (_cache[38] = createBaseVNode("span", { class: "tag" }, "唯一例外", -1)),
              _cache[39] || (_cache[39] = createTextVNode(" 批准「学生申请撤销」要动工单状态，接口现在返回 501，等变更单 CR-001 批了才开。 ", -1)),
              createBaseVNode("button", {
                class: "link",
                onClick: _cache[7] || (_cache[7] = ($event) => {
                  var _a2, _b2, _c2, _d2;
                  return tryCancel({ no: (_b2 = (((_a2 = ex.value) == null ? void 0 : _a2.items) || []).find((x) => x.kind === "CANCEL_REQUEST")) == null ? void 0 : _b2.no, version: (_d2 = (((_c2 = ex.value) == null ? void 0 : _c2.items) || []).find((x) => x.kind === "CANCEL_REQUEST")) == null ? void 0 : _d2.version });
                })
              }, " 点一下试试（会拿到 501） ")
            ]),
            _cache[40] || (_cache[40] = createBaseVNode("div", { class: "foot-note info" }, [
              createBaseVNode("span", { class: "tag" }, "不做"),
              createTextVNode(" 管理端不进流程：不派工、不审批、不催办。看板上唯一的数字目标是「零人工完成率高、返修率低」。 ")
            ], -1))
          ]),
          keeper.value ? (openBlock(), createElementBlock("div", _hoisted_61, toDisplayString(keeper.value), 1)) : createCommentVNode("", true)
        ])
      ]);
    };
  }
};
const Home = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-094f6d7c"]]);
export {
  Home as default
};
