import { o as onMounted, c as createElementBlock, a as createBaseVNode, t as toDisplayString, d as createCommentVNode, F as Fragment, r as renderList, b as createTextVNode, i as createVNode, f as ref, e as useRouter, g as openBlock, n as normalizeClass, j as computed } from "./index-CQHsh9DN.js";
import { B as BottomNav } from "./BottomNav-wi4vEY3F.js";
import { _ as _sfc_main$1 } from "./Plate-3npaODG1.js";
import { _ as _sfc_main$2 } from "./StatusPill-KCmlmcRf.js";
import { _ as _export_sfc, o as ordersApi, d as describeError } from "./_plugin-vue_export-helper-CJxN7Dmm.js";
import "./status-BDo8bc0j.js";
const _hoisted_1 = { class: "top" };
const _hoisted_2 = { class: "tiny muted" };
const _hoisted_3 = { class: "body" };
const _hoisted_4 = {
  key: 0,
  class: "err"
};
const _hoisted_5 = { class: "between" };
const _hoisted_6 = { class: "row" };
const _hoisted_7 = { class: "rno" };
const _hoisted_8 = { class: "tiny muted num" };
const _hoisted_9 = {
  class: "money",
  style: { "margin-top": "11px" }
};
const _hoisted_10 = { class: "n" };
const _hoisted_11 = { class: "n num" };
const _hoisted_12 = {
  key: 0,
  class: "note",
  "data-tone": "warn",
  style: { "margin-top": "10px" }
};
const _hoisted_13 = ["disabled", "onClick"];
const _hoisted_14 = {
  key: 1,
  class: "card empty"
};
const _sfc_main = {
  __name: "Parts",
  setup(__props) {
    useRouter();
    const list = ref([]);
    const meta = ref(null);
    const loading = ref(true);
    const err = ref("");
    const busy = ref("");
    const budgetLine = computed(() => {
      var _a;
      return ((_a = meta.value) == null ? void 0 : _a.budgetLine) ?? 200;
    });
    const over = (o) => Number(o.partsAmount) > budgetLine.value;
    async function load() {
      try {
        const [r, m] = await Promise.all([ordersApi.myOrders("PARTS"), ordersApi.meta()]);
        list.value = r.items || [];
        meta.value = m;
        err.value = "";
      } catch (e) {
        err.value = describeError(e);
      } finally {
        loading.value = false;
      }
    }
    async function arrived(o) {
      busy.value = o.no;
      err.value = "";
      try {
        await ordersApi.partsArrived(o.no, { version: o.version }, { role: "admin" });
        await load();
      } catch (e) {
        err.value = describeError(e);
        if (e.status === 409) load();
      } finally {
        busy.value = "";
      }
    }
    onMounted(load);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("header", _hoisted_1, [
          _cache[0] || (_cache[0] = createBaseVNode("b", null, "等配件", -1)),
          createBaseVNode("span", _hoisted_2, toDisplayString(list.value.length) + " 单", 1)
        ]),
        createBaseVNode("div", _hoisted_3, [
          err.value ? (openBlock(), createElementBlock("p", _hoisted_4, toDisplayString(err.value), 1)) : createCommentVNode("", true),
          (openBlock(true), createElementBlock(Fragment, null, renderList(list.value, (o) => {
            return openBlock(), createElementBlock("div", {
              key: o.no,
              class: "card"
            }, [
              createBaseVNode("div", _hoisted_5, [
                createBaseVNode("div", _hoisted_6, [
                  createVNode(_sfc_main$1, {
                    room: o.room,
                    floor: o.floor,
                    status: "PARTS"
                  }, null, 8, ["room", "floor"]),
                  createBaseVNode("div", null, [
                    createBaseVNode("div", _hoisted_7, toDisplayString(o.floor) + "F-" + toDisplayString(o.room), 1),
                    createBaseVNode("div", _hoisted_8, toDisplayString(o.no), 1)
                  ])
                ]),
                createVNode(_sfc_main$2, { status: "PARTS" })
              ]),
              createBaseVNode("div", _hoisted_9, [
                createBaseVNode("div", null, [
                  createBaseVNode("div", _hoisted_10, toDisplayString(o.partsName || "配件"), 1),
                  _cache[1] || (_cache[1] = createBaseVNode("div", { class: "k" }, "配件", -1))
                ]),
                createBaseVNode("div", null, [
                  createBaseVNode("div", {
                    class: normalizeClass(["n num", { hot: over(o) }])
                  }, "¥" + toDisplayString(o.partsAmount), 3),
                  _cache[2] || (_cache[2] = createBaseVNode("div", { class: "k" }, "金额", -1))
                ]),
                createBaseVNode("div", null, [
                  createBaseVNode("div", _hoisted_11, toDisplayString(o.partsEta || "—"), 1),
                  _cache[3] || (_cache[3] = createBaseVNode("div", { class: "k" }, "预计到货", -1))
                ])
              ]),
              over(o) ? (openBlock(), createElementBlock("div", _hoisted_12, " ¥" + toDisplayString(o.partsAmount) + " 超过 " + toDisplayString(budgetLine.value) + " 元预算线，这单在管理端「超预算采购」清单里等审批。 ", 1)) : createCommentVNode("", true),
              createBaseVNode("button", {
                class: "btn",
                disabled: busy.value === o.no,
                onClick: ($event) => arrived(o)
              }, toDisplayString(busy.value === o.no ? "确认中…" : "到货了，确认收货"), 9, _hoisted_13)
            ]);
          }), 128)),
          !loading.value && !list.value.length ? (openBlock(), createElementBlock("div", _hoisted_14, " 现在没有等配件的单。缺件时在单间作业里登记，配件到了这单会自己回队列。 ")) : createCommentVNode("", true),
          _cache[4] || (_cache[4] = createBaseVNode("div", {
            class: "note",
            style: { "margin-top": "12px" }
          }, [
            createBaseVNode("b", null, "为什么让你填金额"),
            createBaseVNode("br"),
            createTextVNode(" 金额不是走形式：它决定这单要不要管理员批。超过预算线会挂起来等审批，配件到了这单回队列，定级不降。 ")
          ], -1))
        ]),
        createVNode(BottomNav, { role: "worker" })
      ], 64);
    };
  }
};
const Parts = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-9a1acd12"]]);
export {
  Parts as default
};
