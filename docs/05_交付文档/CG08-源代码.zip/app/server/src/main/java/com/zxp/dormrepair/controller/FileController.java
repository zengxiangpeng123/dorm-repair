package com.zxp.dormrepair.controller;

import com.zxp.dormrepair.auth.AuthFilter;
import com.zxp.dormrepair.common.ApiResponses;
import com.zxp.dormrepair.common.BizException;
import com.zxp.dormrepair.domain.Actor;
import com.zxp.dormrepair.file.FileRecord;
import com.zxp.dormrepair.file.FileService;
import com.zxp.dormrepair.service.OrderService;
import com.zxp.dormrepair.statemachine.ActorType;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/** 图片上传与受控读取。文件 ID 由服务端生成，下载必须带有效身份。 */
@RestController
@RequestMapping("/api/v1/files")
public class FileController {

    private final FileService files;
    private final OrderService orders;

    public FileController(FileService files, OrderService orders) {
        this.files = files;
        this.orders = orders;
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> upload(@RequestParam("file") MultipartFile file,
                                      @RequestParam(defaultValue = "BEFORE") String purpose,
                                      HttpServletRequest http) {
        Actor actor = (Actor) http.getAttribute(AuthFilter.ATTR);
        if (actor == null) throw BizException.unauthorized("请先登录");
        String p = purpose == null ? "BEFORE" : purpose.trim().toUpperCase();
        if (!p.equals("BEFORE") && !p.equals("AFTER")) {
            throw BizException.badRequest("purpose 只能是 BEFORE 或 AFTER");
        }
        FileRecord f = files.upload(file, actor, p);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("id", f.id());
        out.put("url", "/api/v1/files/" + f.id());
        out.put("mime", f.mime());
        out.put("byteSize", f.byteSize());
        out.put("sha256", f.sha256());
        return ApiResponses.ok(out);
    }

    @GetMapping("/{id}/metadata")
    public Map<String, Object> metadata(@PathVariable String id, HttpServletRequest http) {
        Actor actor = (Actor) http.getAttribute(AuthFilter.ATTR);
        if (actor == null) throw BizException.unauthorized("请先登录");
        FileRecord f = files.require(id);
        requireCanRead(f, actor);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("id", f.id());
        out.put("mime", f.mime());
        out.put("byteSize", f.byteSize());
        out.put("sha256", f.sha256());
        out.put("purpose", f.purpose());
        return ApiResponses.ok(out);
    }

    @GetMapping("/{id}")
    public ResponseEntity<StreamingResponseBody> download(@PathVariable String id, HttpServletRequest http) {
        Actor actor = (Actor) http.getAttribute(AuthFilter.ATTR);
        if (actor == null) throw BizException.unauthorized("请先登录");
        FileRecord f = files.require(id);
        requireCanRead(f, actor);
        var download = files.download(id);
        long length = download.object().contentLength();
        if (length <= 0) {
            try {
                download.object().stream().close();
            } catch (IOException ignored) {
                // 空对象已确定不可用，关闭失败不改变响应结论。
            }
            throw BizException.notFound("文件对象为空：" + id);
        }
        StreamingResponseBody body = output -> {
            try (var in = download.object().stream()) {
                in.transferTo(output);
            }
        };
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(f.mime()))
                .contentLength(length)
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"photo\"")
                .header("X-Content-Type-Options", "nosniff")
                .header(HttpHeaders.CACHE_CONTROL, "private, no-store, max-age=0")
                .header("Pragma", "no-cache")
                .body(body);
    }

    /** 未绑定文件只给上传者/管理员；已绑定文件继承对应工单的可见范围。 */
    private void requireCanRead(FileRecord file, Actor actor) {
        if (file.orderNo() == null) {
            if (!actor.id().equals(file.uploadedBy()) && actor.type() != ActorType.ADMIN) {
                throw BizException.forbidden("不能读取别人的未绑定文件");
            }
            return;
        }
        orders.detailForActor(file.orderNo(), actor);
    }
}
